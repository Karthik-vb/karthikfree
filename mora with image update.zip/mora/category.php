<htmL>
<head>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<link rel="stylesheet" href="mega-menu.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script src="mega-menu.js"></script>
</head>
<body>
<div class="container-fluid no-padding">
<?php include("./header.php"); ?>
<div class="container" style="margin-top:160px;">
    <div class="row">
        <div class="col">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="./index.php">Home</a></li>
                    <li class="breadcrumb-item"><a href="./subcategory.php?category=1">Category</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo $_GET['category'];?></li>
                </ol>
            </nav>
        </div>
	</div>
	<?php if($_GET['category']=='ACRYLIC'){ ?>
		<div class="row">
	
	<!-- BEGIN PRODUCTS -->
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/2ply1.jpg" alt="...">
			  <h4>2ply Blanket</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img  class="img-responsive box-img1" src="./images/MGold1.jpg" alt="...">
			  <h4>Gold Digital</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
		   <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/2ply2.jpg" alt="...">
			  <h4>Harmony</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			  <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	</div>
	<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Mora-Gold1.jpg" alt="...">
			  <h4>Mora Gold</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			  <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	</div>
   
	
  
	 </div>
	 <div class="row">
	
	<!-- BEGIN PRODUCTS -->
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/MORA-MAGIC1.jpg" alt="...">
			  <h4>Mora Magic</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	 
   
	
  
	 </div>
<?php } ?>
<?php if($_GET['category']=='DOUBLEBLANKET'){ ?>
		<div class="row">
	
	<!-- BEGIN PRODUCTS -->
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/3D-ART.jpg" alt="...">
			  <h4>3D ART</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img  class="img-responsive box-img1" src="./images/Arabesco.jpg" alt="...">
			  <h4>Arabescco</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
		   <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Mora-Color.jpg" alt="...">
			  <h4>Color </h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			  <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	</div>
	<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/MG_Digital_Embroidery.jpg" alt="...">
			  <h4>Gold Digital Embroidery</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			  <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	</div>
   
	
  
	 </div>
	 <div class="row">
	
	<!-- BEGIN PRODUCTS -->
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/MoraImperialEmbossed.jpg" alt="...">
			  <h4>Imperial Embossed</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	 
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img  class="img-responsive box-img1" src="./images/INFINITY.jpg" alt="...">
			  <h4>Infinity </h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
		   <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Mora_luxury_Plus.jpg" alt="...">
			  <h4>Luxury Blanket </h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			  <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	</div>
	<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Marble.jpg" alt="...">
			  <h4>Marble</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			  <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	</div>
	
  
	 </div>
	 <div class="row">
	
	<!-- BEGIN PRODUCTS -->
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/MicroCoral.jpg" alt="...">
			  <h4>Micro Coral</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	 
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img  class="img-responsive box-img1" src="./images/Mora-Gold_1.jpg" alt="...">
			  <h4>Mora Gold  </h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
		   <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/MGold_Digital_1.jpg" alt="...">
			  <h4>Mora Gold Digital  </h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			  <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	</div>
	<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/MORA-MAGIC_1.jpg" alt="...">
			  <h4>MORA MAGIC</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			  <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	</div>
	
  
	 </div>
	 <div class="row">
	
	<!-- BEGIN PRODUCTS -->
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Sofing.jpg" alt="...">
			  <h4>Mora Sofing</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	 
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img  class="img-responsive box-img1" src="./images/NovaLinea.jpg" alt="...">
			  <h4>Novalinea  </h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
		   <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Serena.jpg" alt="...">
			  <h4>Serena  </h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			  <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	</div>
	<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/silver1.jpg" alt="...">
			  <h4>Silver Ion</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			  <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	</div>
	
  
	 </div>
	 <div class="row">
	
	<!-- BEGIN PRODUCTS -->
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Topitos1.jpg" alt="...">
			  <h4>Topitos XL</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	 
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img  class="img-responsive box-img1" src="./images/gift.jpg" alt="...">
			  <h4>Wedding Gift</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
		   <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  </div>
<?php } ?>
<?php if($_GET['category']=='Set4Piece'){ ?>
		<div class="row">
	
	<!-- BEGIN PRODUCTS -->
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/MGold_1.jpg" alt="...">
			  <h4>Mora Gold</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img  class="img-responsive box-img1" src="./images/MGold_Digital_2.jpg" alt="...">
			  <h4>Mora Gold Digital</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
		   <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	 
	
  
	 </div>
<?php } ?>
<?php if($_GET['category']=='SingleBLANKET'){ ?>
		<div class="row">
	
	<!-- BEGIN PRODUCTS -->
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Mora-Color_1.jpg" alt="...">
			  <h4>Color</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img  class="img-responsive box-img1" src="./images/MoraColor_1.jpg" alt="...">
			  <h4>Color Printed</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
		   <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/MGold_Digital_3.jpg" alt="...">
			  <h4>Gold Digital</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			  <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	</div>
	<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Harmony_1.jpg" alt="...">
			  <h4>Harmony </h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			  <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	</div>
   
	
  
	 </div>
	 <div class="row">
	
	<!-- BEGIN PRODUCTS -->
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/MoraGold_01.jpg" alt="...">
			  <h4>Mora Gold</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	 
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Sofing_01.jpg" alt="...">
			  <h4>Mora Sofing</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/SERENA_02.jpg" alt="...">
			  <h4>Serena </h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Topitos_1.jpg" alt="...">
			  <h4>Topitos </h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	
  
	 </div>
<?php } ?>
<?php if($_GET['category']=='FURSCollection'){ ?>
		<div class="row">
	
	<!-- BEGIN PRODUCTS -->
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/ANTARTIDA.jpg" alt="...">
			  <h4>Antartida</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img  class="img-responsive box-img1" src="./images/kibo.jpg" alt="...">
			  <h4>Kibo</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
		   <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Kolari.jpg" alt="...">
			  <h4>Kolari </h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			  <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	</div>
	<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Laponia.jpg" alt="...">
			  <h4>Laponia</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			  <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	</div>
   
	
  
	 </div>
	 <div class="row">
	
	<!-- BEGIN PRODUCTS -->
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/LOGAN_1.jpg" alt="...">
			  <h4>Logan </h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	 
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Moscú.jpg" alt="...">
			  <h4>Moscu </h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Venus-Plus.jpg" alt="...">
			  <h4>Venus Plus </h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/YUKON.jpg" alt="...">
			  <h4>YUKON </h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	
  
	 </div>
<?php } ?>
<?php if($_GET['category']=='Elegance'){ ?>
		<div class="row">
	
	<!-- BEGIN PRODUCTS -->
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/YUKON_1.jpg" alt="...">
			  <h4>YUKON</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img  class="img-responsive box-img1" src="./images/kibo1.jpg" alt="...">
			  <h4>KIBO</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
		   <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/LOGAN_G0.jpg" alt="...">
			  <h4>LOGAN</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			  <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	</div>
	<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/ANTARTIDA1.jpg" alt="...">
			  <h4>ANTARTIDA</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			  <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	</div>
   
	
  
	 </div>
	 <div class="row">
	
	<!-- BEGIN PRODUCTS -->
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Venus-Plus_1.jpg" alt="...">
			  <h4>Venus Plus Blanket</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	 <!-- BEGIN PRODUCTS -->
	 <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Laponia1.jpg" alt="...">
			  <h4>Laponia Blanket</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
   <!-- BEGIN PRODUCTS -->
   <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Kolari_1.jpg" alt="...">
			  <h4>Kolari Blanket</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	<!-- BEGIN PRODUCTS -->
	<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Moscú1.jpg" alt="...">
			  <h4>Moscu Blanket</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
  
	 </div>
<?php } ?>
<?php if($_GET['category']=='SummerQuilts'){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/Colcha.jpg" alt="...">
      			<h4>Colcha</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
                <div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
  		</div>
  	
  	
		 </div>
<?php } ?>
        
<?php if($_GET['category']=='SingleBedSheets'){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/image15.jpeg" alt="...">
      			<h4>Bed Sheet - شرشف</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
                <div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
  		</div>
  		
        
  	
		 </div>
<?php } ?>
<?php if($_GET['category']=='DoubleBedSheets'){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/image15.jpeg" alt="...">
      			<h4>Double Bed Sheets</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
                <div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
  		</div>
  		
        
  	
		 </div>
<?php } ?> 
<?php if($_GET['category']=='KingBedSheets'){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/image15.jpeg" alt="...">
      			<h4>King Bed Sheets</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
                <div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
  		</div>
  		
        
  	
		 </div>
<?php } ?> 
<?php if($_GET['category']=='FittedBedSheets'){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/image15.jpeg" alt="...">
      			<h4>Fitted Bed Sheets</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
                <div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
  		</div>
  		
        
  	
		 </div>
<?php } ?>     
<?php if($_GET['category']=='BabyPillow'){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/Baby-Pillow1.jpg" alt="...">
      			<h4>Baby Pillow</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
                <div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
  		</div>
  	
        
  	
		 </div>
<?php } ?>  
<?php if($_GET['category']=='LuxuryPillow'){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/luxplus_pillow1.jpg" alt="...">
      			<h4>Luxury Pillow</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
      			<div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
        </div>
        
  	
		 </div>
<?php } ?>  
<?php if($_GET['category']=='MedicatedPillow'){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/biogreen.jpg" alt="...">
      			<h4>Medicated Pillow</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
      			<div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
        </div>
        
  	
		 </div>
<?php } ?>  
<?php if($_GET['category']=='OrientalCarpets'){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/carpet4.jpeg" alt="...">
      			<h4>Oriental Carpets</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
                <div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
  		</div>
        
  	
		 </div>
<?php } ?>  
<?php if($_GET['category']=='PlushCarpets'){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img  class="img-responsive box-img1" src="./images/carpet1.jpeg" alt="...">
      			<h4>Plush Carpets</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
               <div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
  		</div>
  	
		 </div>
<?php } ?> 
<?php if($_GET['category']=='ShagCarpets'){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/carpet2.jpeg" alt="...">
      			<h4>Shag Carpets</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
      			<div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
        </div>
  	
		 </div>
<?php } ?> 
<?php if($_GET['category']=='CutPileCarpets'){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/carpet3.jpeg" alt="...">
      			<h4>Cut Pile Carpets</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
      			<div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
        </div>
  	
		 </div>
<?php } ?> 
<?php if($_GET['category']=='LoopPileCarpets'){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/carpet2.jpeg" alt="...">
      			<h4>Loop Pile Carpets</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
      			<div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
        </div>
  	
		 </div>
<?php } ?> 
<?php if($_GET['category']=='CutLoopCarpets'){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img  class="img-responsive box-img1" src="./images/carpet1.jpeg" alt="...">
      			<h4>Cut&Loop Carpets</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
               <div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
  		</div>
  	
		 </div>
<?php } ?> 
<?php if($_GET['category']=='FlatweaveCarpets'){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/carpet2.jpeg" alt="...">
      			<h4>Flat weave Carpets</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
      			<div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
        </div>
  	
		 </div>
<?php } ?> 

</div>

<?php include("./footer.php"); ?>
</div>
</body>
</html>