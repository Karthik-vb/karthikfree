<footer>
<div style="min-height: 261px;" class="footer" id="footer-sub">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <h5> ONLINE SHOPPING </h5>
            <ul>
                <li><a href="">Men</a><hr></li>
                <li><a href="">Womer</a><hr></li>
                <li><a href="">House & Living</a><hr ></li>
                <li><a href="">Offers</a><hr></li>
                <li><a href="">Myntra Insiders</a></li>               
            </ul>
            </div>

             <div class="col-md-2">
                <h5> USEFUL LINKS </h5>
            <ul>
            <li><a href="">Payments</a><hr></li>
                <li><a href="">Saved Cards</a><hr></li>
                <li><a href="">Shipping</a><hr ></li>
                <li><a href="">Cancellation & Returns</a><hr></li>
                <li><a href="">FAQ</a></li>               
            </ul>
        </div>

         <div class="col-md-4">
            <h5>  EXPERIENCE MYNTRA APP ON MOBILE  </h5>
            <a href=""><img class="desktop-iOSDownLink" src="https://constant.myntassets.com/web/assets/img/bc5e11ad-0250-420a-ac71-115a57ca35d51539674178941-apple_store.png"></a>
            <a href=""><img class="desktop-androidDownLink" src="https://constant.myntassets.com/web/assets/img/80cc455a-92d2-4b5c-a038-7da0d92af33f1539674178924-google_play.png"></a>
            <div class="desktop-keepInTouch"> KEEP IN TOUCH </div>
            <a href="#" class="desktop-facebook" ><img src="https://constant.myntassets.com/web/assets/img/d2bec182-bef5-4fab-ade0-034d21ec82e31574604275433-fb.png" style="width: 20px; height: 20px;"></a>
            <a href="#" class="desktop-twitter"><img src="https://constant.myntassets.com/web/assets/img/f10bc513-c5a4-490c-9a9c-eb7a3cc8252b1574604275383-twitter.png" style="width: 20px; height: 20px;"></a>
            <a href="#" class="desktop-youtube" ><img src="https://constant.myntassets.com/web/assets/img/a7e3c86e-566a-44a6-a733-179389dd87111574604275355-yt.png" style="width: 28px; height: 20px;"></a>
            <a href="#" class="desktop-instagram" ><img src="https://constant.myntassets.com/web/assets/img/b4fcca19-5fc1-4199-93ca-4cae3210ef7f1574604275408-insta.png" style="width: 20px; height: 22px; position: relative; top: 1px;"></a>
        </div>
        <div class="col-md-3">
        <div class="desktop-promises"><div class="desktop-section" ><div class="desktop-original" ><img src="https://constant.myntassets.com/web/assets/img/6c3306ca-1efa-4a27-8769-3b69d16948741574602902452-original.png" style="width: 48px; height: 40px;"></div><div ><strong >100% ORIGINAL </strong>guarantee for all products at myntra.com </div></div>
        <div class="desktop-section" ><div class="desktop-return" ><img src="https://constant.myntassets.com/web/assets/img/ef05d6ec-950a-4d01-bbfa-e8e5af80ffe31574602902427-30days.png" style="width: 48px; height: 49px;"></div><div><strong data-reactid="114">Return within 30days </strong>of receiving your order</div></div><div class="desktop-section" ><div class="desktop-delivery"><img src="https://constant.myntassets.com/web/assets/img/cafa8f3c-100e-47f1-8b1c-1d2424de71041574602902399-truck.png" style="width: 48px; height: 43px;"></div><div ><strong >Get free delivery </strong>for every order above Rs. 799</div></div></div>
        </div>
        </div>

        
 <hr style="margin-bottom:0px; margin-top:30px; padding:0px;">
        <!-- <div class="row" id="sub-two">

            <div class="col-md-4">
                <div class="vertical-line text-center">
                    <span class="glyphicon glyphicon-map-marker"></span>
                    <h4>TRACK YOUR ORDER</h4>
                </div>
            </div>

            <div class="col-md-4">
                <div class="vertical-line text-center">
                    <span class="glyphicon glyphicon-refresh"></span>
                    <h4>FREE & EASY RETURNS</h4>
                </div>
            </div>

            <div class="col-md-4">
                <div style="margin:8px;" class="text-center">
                    <span class="glyphicon glyphicon-remove-circle"></span>
                    <h4 style="color:#6d6c6c;">ONLINE CANCELLATIONS</h4>
                </div>
            </div>
            

        </div> --> 

    </div>
</div>
<!-- <div style="min-height: 50px;" id="footer-main">

<ul>
    <li><a href=""><b>About Us</b></a></li>
    <li><a href=""><b>Partner with us</b></a></li>
    <li><a href=""><b>Terms & Conditions</b></a></li>
    <li><a href=""><b>Blog</b></a></li>
    <li><a href=""><b>Customer Service</b></a></li>
</ul>

<div id="social-menu">
    <ul>
    <li><a href=""><img style="max-width:18px; margin-top: -7px;" src=""></a></li>
    <li><a href=""><img style="max-width:18px; margin-top: -7px;" src=""></a></li>
    <li><a href=""><img style="max-width:18px; margin-top: -7px;" src=""></a></li>
</ul>
</div>

</div> -->
</footer>