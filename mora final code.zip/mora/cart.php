<htmL>
<head>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<link rel="stylesheet" href="mega-menu.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script src="mega-menu.js"></script>
<style>
  .desktop-base-cartLayout {
    max-width: 980px;
    margin: auto;
    padding: 0 10px 16px;
    min-height: 320px;
    color: #282c3f;
    margin-top: -20px;
}
.itemBlock-base-leftBlock {
    display: inline-block;
    width: 70%;
    padding-right: 20px;
    border-right: 1px solid #eaeaec;
    padding-top: 32px;
}
.offersV2-base-container {
    background: #fff;
    margin-bottom: 10px;
    padding: 16px 18px 12px;
    border: 1px solid #eaeaec;
    border-radius: 4px;
    font-size: 12px;
    position: relative;
}
.offersV2-base-title {
    font-weight: 600;
    font-size: 14px;
    margin-left: 30px;
    margin-bottom: 12px;
}
.offersV2-base-message {
    padding-left: 15px;
    text-indent: -15px;
    list-style: none;
    white-space: normal;
    margin-bottom: 8px;
}
.offersV2-base-more {
    padding-left: 3px;
    font-size: 14px;
    font-weight: 600;
    text-transform: capitalize;
    color: #ff3f6c;
    cursor: pointer;
    display: inline-block;
}
.shippingTip-base-deliveryTip {
    padding: 8px;
    margin-bottom: 12px;
    background: #fff;
    border: 1px solid #eaeaec;
    border-radius: 4px;
}
.shippingTip-base-tipMessage {
    display: inline-block;
    vertical-align: middle;
    color: #3e4152;
    font-size: 14px;
    margin-top: 5px;
    width: 80%;
}
.shippingTip-base-tipBold {
    display: inline-block;
    margin-left: 1px;
    color: #535766;
    font-weight: 600;
}
.itemBlock-base-itemHeader {
    padding: 8px 12px 18px;
}
.itemBlock-base-itemHeader div {
    font-size: 16px;
    font-weight: 600;
    display: inline-block;
}
.itemBlock-base-itemHeader div {
    font-size: 16px;
    font-weight: 600;
    display: inline-block;
}
.itemBlock-base-totalCartValue {
    float: right;
    font-weight: 600;
}
.itemContainer-base-itemMargin:last-child {
    margin-bottom: 0;
}
.item-base-item:last-child {
    margin-bottom: 0;
}
.item-base-item {
    position: relative;
    margin-bottom: 8px;
}
.itemContainer-base-item {
    background: #fff;
    font-size: 14px;
    border: 1px solid #eaeaec;
    border-radius: 4px;
    position: relative;
    padding: 12px 12px 0;
}
.itemContainer-base-itemLeft {
    position: absolute;
}
.image-base-imgResponsive {
    display: block;
    max-width: 100%;
    height: 148px;
}
.itemContainer-base-itemRight {
    padding-left: 12px;
    position: relative;
    min-height: 148px;
    margin-left: 111px;
    margin-bottom: 12px;
}
.itemContainer-base-details {
    min-height: 97px;
}
.itemContainer-base-details, .itemContainer-base-itemLink {
    text-decoration: none !important;
    padding-bottom: 3px !important;
    color: #282c3f;
    margin-right: 6px;
}
.itemContainer-base-brand {
    font-weight: 600;
}
.itemContainer-base-brand {
    margin-bottom: 4px;
}
.itemContainer-base-brand, .itemContainer-base-itemLink, .itemContainer-base-itemName {
    width: 80%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    line-height: 16px;
}
.itemContainer-base-itemLink {
    display: block;
}
.itemContainer-base-details, .itemContainer-base-itemLink {
    text-decoration: none;
    padding-bottom: 0;
    margin-right: 6px;
}
.itemComponents-base-sellerContainer {
    margin-top: 2px;
    margin-bottom: 12px;
    display: flex;
    flex-direction: row;
}
.itemComponents-base-sellerData {
    font-size: 12px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 62%;
    display: inline;
    color: #94969f;
}
.itemContainer-base-sizeAndQty {
    padding: 12px 0;
    display: inline-block;
    margin-right: 8px;
}
.itemComponents-base-quantityNew, .itemComponents-base-size {
    display: inline-block;
    color: #282c3f;
    font-weight: 600;
    cursor: pointer;
    border-radius: 2px;
    line-height: 16px;
}
.itemComponents-base-size {
    padding: 2px 8px;
    background: #f5f5f6;
    margin-right: 12px;
}
.itemComponents-base-dropDown {
    font-size: 16px;
    color: #282c3f;
    cursor: pointer;
    margin-left: 5px;
    position: relative;
    top: -2px;
}
.itemComponents-base-quantity {
    display: inline-block;
    padding: 2px 8px;
    background: #f5f5f6;
    color: #282c3f;
    font-weight: 600;
    cursor: pointer;
    border-radius: 2px;
    line-height: 16px;
}
.itemContainer-base-amount {
    position: absolute;
    top: 10px;
    right: 12px;
}
.itemComponents-base-bold {
    font-weight: 600;
}
.itemComponents-base-price {
    display: inline-block;
    color: #282c3f;
}
.itemContainer-base-discountStrikedAmount {
    position: absolute;
    top: 32px;
    right: 12px;
}
.itemComponents-base-strikedAmount {
    display: inline-block;
}
.itemComponents-base-discountAbsoluteRupee, .itemComponents-base-itemDiscount, .itemComponents-base-percentageDiscountText {
    color: #f16565;
}
.itemComponents-base-price.itemComponents-base-strike {
    color: #94969f;
    padding: 0 8px;
}
.inlinebuttonV2-base-actions {
    border-top: 1px solid #eaeaec;
}
.itemContainer-base-itemActions:first-child {
    width: 111px;
}
.itemContainer-base-itemActions {
    line-height: 20px;
}
.inlinebuttonV2-base-action {
    display: inline-block;
    width: 49%;
    text-align: center;
    margin: 12px 0;
}
.itemContainer-base-inlineButton {
    font-size: 13px!important;
    letter-spacing: .5px;
    padding: 0;
}
.itemComponents-base-rupeeIcon {
    font-size: 12px;
    fill: #282c3f;
}
.itemComponents-base-strike {
    text-decoration: line-through;
}
.inlinebuttonV2-base-actionButton {
    text-transform: uppercase;
    font-weight: 600;
    color: #696b79;
    padding: 0;
    height: 20px;
    font-size: 12px;
    text-decoration: none;
    border: none;
    background: none;
    cursor: pointer;
}
.inlinebuttonV2-base-action:last-child {
    border-left: 1px solid #d4d5d9;
}
.addToWishlist-base-wishlistBlock {
    display: block;
    text-decoration: none;
    background-color: #fff;
    color: inherit;
    padding: 12px;
    position: relative;
    font-weight: 600;
    padding: 16px 12px 16px 16px;
    margin-top: 24px;
    border: 1px solid #eaeaec;
    border-radius: 4px;
}
.addToWishlist-base-wishlistText {
    display: inline-block;
    margin-left: 10px;
    font-size: 14px;
    color: #282c3f;
}
.addToWishlist-base-wishlistChevron {
    float: right;
    font-size: 20px;
    color: #282c3f;
}
.priceBlock-base-container {
    margin-bottom: 16px;
}
.priceBlock-base-priceHeader {
    font-size: 12px;
    font-weight: 600;
    margin: 24px 0 16px;
    color: #535766;
}
.priceBreakUp-base-orderSummary {
    font-size: 14px;
}
.priceDetail-base-row {
    margin-bottom: 12px;
    line-height: 16px;
}
.priceDetail-base-value {
    float: right;
}
.priceDetail-base-discount {
    color: #03a685;
}
.priceDetail-base-action {
    font-size: 14px;
    color: #ff3f6c;
    cursor: pointer;
}
.priceDetail-base-spaceRight {
    padding-right: 4px;
}
.priceDetail-base-striked {
    text-decoration: line-through;
}
.coupons-base-header {
    font-size: 12px;
    font-weight: 600;
    color: #535766;
    text-transform: uppercase;
    margin-bottom: 12px;
}
.coupons-base-content {
    padding-bottom: 12px;
    position: relative;
    border-bottom: 1px solid #f5f5f6;
    padding-left: 36px;
}
.coupons-base-label {
    font-weight: 600;
    font-size: 14px;
    line-height: 16px;
    padding: 7px 0;
}
.desktop-base-right {
    vertical-align: top;
    display: inline-block;
    width: 29%;
    padding: 24px 0 0 16px;
}
.coupons-base-button {
    float: right;
    padding: 4px 16px;
    position: absolute;
    color: #ff3f6c;
    border: 1px solid #ff3f6c;
    border-radius: 3px;
    text-transform: none;
    cursor: pointer;
    font-weight: 600;
    top: 0;
    right: 0;
    background: #fff;
}
.coupons-base-couponMessage {
    display: inline-block;
    font-size: 14px;
    margin-top: 10px;
}
.coupons-base-logIn {
    color: #ff3f6c;
    font-weight: 600;
}
.priceDetail-base-total {
    font-weight: 600;
    font-size: 15px;
    padding-top: 16px;
    border-top: 1px solid #eaeaec;
    color: #3e4152;
    line-height: 16px;
}
.button-base-button {
    color: #fff;
    font-size: 14px;
    font-weight: 600;
    padding: 10px;
    background: #ff3f6c;
    cursor: pointer;
    text-align: center;
    border: none;
    border-radius: 2px;
    text-transform: uppercase;
    letter-spacing: 1px;
}
.coupons-base-couponIcon {
    position: absolute;
    left: 0;
    font-size: 18px;
    top: 7px;
}
.offersV2-base-discountIcon {
    position: absolute;
    font-size: 18px;
}
.shippingTip-base-tipIcon {
    display: inline-block;
    vertical-align: middle;
    margin-right: 10px;
    font-size: 18px;
}
.cartheader {
    border-bottom: 1px solid #F5F5F6;
}
.cartheader {
    border-bottom: 1px solid #F5F5F6;
    font-size: 12px;
    font-weight: 600;
}
.cartheader .container {
    line-height: 78px;
}
.site-nav-container {
    background-color: #fff;
    width: 100%;
    max-width: 92%;
    margin: auto;
}
.cartheader .myntra-logo {
    height: 40px;
    width: 40px;
    float: left;
}
.cartheader .checkout-steps {
    margin: 0 0 0 34%;
    width: 40%;
    color: #696B79;
    padding: 0;
    display: inline-block;
    line-height: 20px;
}
.cartheader .checkout-steps .active {
    color: #20BD99;
    border-bottom: 2px solid #20BD99;
}
.cartheader .checkout-steps .step1 {
    margin: 0 5px 0 0;
}
.cartheader .checkout-steps .step {
    display: inline-block;
    letter-spacing: 3px;
}
.cartheader .checkout-steps .divider {
    display: inline-block;
    border-top: 1px dashed #696B79;
    height: 4px;
    width: 10%;
}
.cartheader .secureContainer {
    float: right;
    max-height: 78px;
    margin-top: -20px;
}
.cartheader .secureContainer .secureIcon {
    margin: 23px 5px 0 0;
    color: #10caa5;
    font-size: 18px;
}

.cartheader .secureContainer .secure {
    float: right;
    letter-spacing: 3px;
    color: #535766;
    margin: -8px 20px 0px 8px;
}
.checkout-footer {
    border-top: 1px solid #F5F5F6;
    margin: 0 0 40px 0;
}
.checkout-footer .content {
    max-width: 980px;
    padding-top: 10px;
    margin: auto;
}
.checkout-footer .images {
    display: inline-block;
}
.checkout-footer .content .contact-us {
    color: #282c3f;
    text-decoration: none;
    font-weight: 600;
}
.checkout-footer .content .contact-us span {
    float: right;
    font-size: 14px;
    padding: 10px 0;
}
.credit-cards img
{
  border: 1px solid #dae2e4;
    margin: 4px;
}
  </style>
</head>
<body>
<div class="container-fluid no-padding" >
<?php include("./header.php"); ?>
<div class="cartheader"  style="margin-top:110px;margin-bottom:20px"> <div class="site-nav-container container"> <div class="myntra-logo"></div>
<ol class="checkout-steps"> <li class="step step1 active">BAG</li> <li class="divider"></li> <li class="step step2">ADDRESS</li> <li class="divider"></li> <li class="step step3">PAYMENT</li> </ol>
<div class="secureContainer"> <i class="fa fa-shield secureIcon" aria-hidden="true"></i> <div class="secure">100% SECURE</div> </div>
</div></div>
<div class="container">

<div class="desktop-base-cartLayout">
  <div class="itemBlock-base-leftBlock">
  <div class="offersV2-base-container">
  <i class="fa fa-gift offersV2-base-discountIcon" aria-hidden="true"></i>
  <div class="offersV2-base-title">Available Offers</div>
  <div><li class="offersV2-base-message "><span>10% Instant Discount up to  KWD.100 with HDFC Bank Credit Cards on a minimum spend of KWD.3,000. TCA</span></li><div class="offersV2-base-more">Show More</div></div>
</div>
<div><div class="shippingTip-base-deliveryTip"><div class="sprite-ship-free shippingTip-base-tipIcon"><i class="fa fa-truck" aria-hidden="true"></i></div><div class="shippingTip-base-tipMessage">Yay!<span class="shippingTip-base-tipBold">&nbsp;No handling fee&nbsp;</span>on this order.</div></div></div>
<div class="itemBlock-base-itemHeader"><div>My Shopping Bag (1 Item)</div><div class="itemBlock-base-totalCartValue">Total: KWD.17,375</div></div>
<div id="cartItemsList"><div class="itemContainer-base-itemMargin"><div><div class="item-base-item"><div class="itemContainer-base-item "><div class="itemContainer-base-itemLeft"><a href="#"><div style="background: rgb(255, 242, 223); height: 148px; width: 111px;"><div class="LazyLoad is-visible" style="height: 148px; width: 111px;"><img class="img-responsive image-base-imgResponsive" src="./images/2Ply1.jpg" alt="..."></div></div></a></div><div class="itemContainer-base-itemRight"><div class="itemContainer-base-details"><div><div class="itemContainer-base-brand">2ply Blanket</div><a class="itemContainer-base-itemLink" href="#">Gold is a range of premium blankets</a></div><div class="itemComponents-base-sellerContainer"><div class="itemComponents-base-sellerData">Sold by: Mora Spain</div></div><div class="itemContainer-base-sizeAndQty"><div class="itemComponents-base-size"><span class="">Size: King Size</span><svg xmlns="http://www.w3.org/2000/svg" width="6" height="3" viewBox="0 0 6 3" class="itemComponents-base-dropDown"><path fill-rule="evenodd" d="M0 0h6L3 3z"></path></svg></div><div class="itemComponents-base-quantity"><span class="">Qty: 1</span><svg xmlns="http://www.w3.org/2000/svg" width="6" height="3" viewBox="0 0 6 3" class="itemComponents-base-dropDown"><path fill-rule="evenodd" d="M0 0h6L3 3z"></path></svg></div></div><div><div class="itemComponents-base-price itemComponents-base-bold itemContainer-base-amount"><div>KWD.17,375</div></div><div class="itemContainer-base-discountStrikedAmount"><span class="itemComponents-base-strikedAmount"><span class="itemComponents-base-price itemComponents-base-strike itemContainer-base-strikedAmount">KWD.17,800</span></span><span class="itemComponents-base-itemDiscount">5% OFF</span></div></div><div></div></div></div><div class="inlinebuttonV2-base-actions "><div class="inlinebuttonV2-base-action itemContainer-base-itemActions"><button class="inlinebuttonV2-base-actionButton itemContainer-base-inlineButton removeButton">Remove</button></div><div class="inlinebuttonV2-base-action itemContainer-base-itemActions"><button class="inlinebuttonV2-base-actionButton itemContainer-base-inlineButton  wishlistButton">Move to WishList</button></div></div></div></div></div></div></div>
<a href="/wishlist"><div><div class="addToWishlist-base-wishlistBlock"> <span class="glyphicon glyphicon-bookmark" style="padding:5px;color:#000;"></span><div class="addToWishlist-base-wishlistText">Add More From Wishlist</div><i class="fa fa-chevron-right addToWishlist-base-wishlistChevron"></i></div></div></a>
</div>
<div class="desktop-base-right"><div><div><div><div class="coupons-base-header">Coupons</div><div class="coupons-base-content"><i class="fa fa-tag coupons-base-couponIcon"></i> <div class="coupons-base-label "> Apply Coupons</div><div><button class="coupons-base-button">APPLY</button></div><div class="coupons-base-couponMessage"><a href="/login?referer=/checkout/cart" class="coupons-base-logIn">Login</a><span> to see best coupons for you</span></div></div></div></div></div><div class="priceBlock-base-container"><div class="priceBlock-base-priceHeader">PRICE DETAILS (1 Item)</div><div class="priceBreakUp-base-orderSummary" id="priceBlock"><div class="priceDetail-base-row"><span>Total MRP</span><span class="priceDetail-base-value "><span></span><span>KWD.17,375</span></span></div><div class="priceDetail-base-row"><span>Discount on MRP</span><span class="priceDetail-base-value priceDetail-base-discount"><span>-</span><span>KWD.425</span></span></div><div class="priceDetail-base-row"><span>Coupon Discount</span><span class="priceDetail-base-value priceDetail-base-action">Apply Coupon</span></div><div class="priceDetail-base-row"><span>Platform Handling Fee</span><i class="fa fa-info-circle" style="padding-left:5px;color:#000;" aria-hidden="true"></i><span class="priceDetail-base-value"><span class="priceDetail-base-striked priceDetail-base-spaceRight"><span>KWD.49</span></span><span class="priceDetail-base-discount">FREE</span></span></div><div class="priceDetail-base-total"><span>Total Amount</span><span class="priceDetail-base-value "><span></span><span>KWD.17,375</span></span></div></div></div><div><a><div class="button-base-button  ">Place Order</div></a></div></div>
</div> 
     
</div>
<div class="checkout-footer"> <div class="content"> 
  <div class="images"> 
  <div class="credit-cards" style="text-align: center; width: 100%">
  <img height="40" width="70px"  src="./images/card_visa.png"/>
  <img height="40" width="70px" style="padding:5px"  src="./images/card_master.png"/>
  <img height="40" width="70px" style="padding:5px" src="./images/card_paypal.png"/>
  <img height="40" width="70px" src="./images/gpay.jpg"/>
  <img height="40" width="70px" style="padding:5px" src="./images/card_amex.png"/>
  <img height="40" width="70px" src="./images/netbank.png"/>
  <img height="40" width="70px" src="./images/bhim.png"/>
  <img height="40" width="70px" src="./images/rupay.png"/>
  <!-- <img height="40" width="70px" src="./images/cod.png"/> -->
  <img height="40" width="70px" src="./images/paytm.jpg"/>
</div>
     </div>
   <a href="/contactus" class="contact-us"> <span>Need Help ? Contact Us</span> </a> </div></div>        
<?php include("./footer.php"); ?>
</div>
</body>
</html>