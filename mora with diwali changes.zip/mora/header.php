

              
<nav class="navbar navbar-icon-top navbar-default navbar-fixed-top">
<div class="container-fluid">
        <!--brand, search-->
        <div class="row">
        <div class="navbar-header">
         <button type="button" class="navbar-toggle nav-btns" data-toggle="collapse" data-target="#main-navbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
            <a  href="./index.php"><img src="./images/dlogo.jpg" class="logo-header"></a>
           
         </div>
<!-- <ul class="nav navbar-nav navbar-right mobilehide">
            <li>
             <form class="navbar-form navbar-search" role="search">
                <div class="input-group search-form">
                
                    <div class="input-group-btn">
                        <button type="button" class="btn btn-search btn-default dropdown-toggle" data-toggle="dropdown">
                            <span class="glyphicon glyphicon-search"></span>
                            <span class="label-icon">ALL</span>
                            <span class="caret"></span>
                        </button>
                        <ul class="dropdown-menu searchdrop" role="menu">
                           <li class="slist">
                                <a href="#">
                                    <span class="label-icon">Blanket  - بطانيات</span>
                                </a>
                            </li>
                            <li class="slist">
                                <a href="#">
                             
                                <span class="label-icon">Quilt - لحاف</span>
                                </a>
                            </li>
                            <li class="slist">
                                <a href="#">
                                <span class="label-icon">Pillows - مخدات</span>
                                </a>
                            </li>
                        </ul>
                    </div>
        
                    <input type="text" class="form-control search-input">
                
                    <div class="input-group-btn">
                        <button type="button" class="btn btn-search btn-default">
                        GO
                        </button>
                         
                         
                    </div>
                </div>  
            </form>   
              </li>
            <li class="dropdown mega-dropdown">
                  <a href="#" class="dropdown-toggle" style="border-bottom-color:#0db7af;" data-toggle="dropdown" role="button" aria-expanded="false">Account & Lists</a>

                  <ul class="dropdown-menu mega-dropdown-menu row accountlist">
                     
                     <li class="col-sm-6">
                        <ul>
                           <li class="dropdown-header green">Your List</li>
                           <li class='green1'><a href="#">Wishlist</a></li>
                           <li class='green1'><a href="#">Payment History</a></li>
                           <li class='green1'><a href="#">Your Dabbous Membership </a></li>
                           <li class='green1'><a href="#">Your Dabbous bussiness card</a></li>
                           <li class='green1'><a href="#">Your Dabbous Rewards Points</a></li>
                        </ul>
                     </li>
                     <li class="col-sm-6">
                        <ul>
                           <li class="dropdown-header green">Your Account</li>
                            <li class='green1'><a href="#">Account</a></li>
                           <li class='green1'><a href="#">Your Order</a></li>
                           <li class='green1'><a href="#">Saved cards </a></li>
                           <li class='green1'><a href="#">Delivery Address</a></li>
                           <li class='green1'><a href="#">Sign out</a></li>

                        </ul>
                     </li>
                  </ul>

               </li>
                    <li >
                        <a href="./cart.php" class="shop-btn" style="border:none;">
                        <i class="fa fa-shopping-cart icon-cart">
                                <span class="badge badge-danger">11</span>
                            </i><br>
                            AddToCart
                        </a>
                    </li>
               </ul> -->
<!-- </div>
        
<div class="row">  -->

         <div class="collapse navbar-collapse" id="main-navbar">
            <ul class="nav navbar-nav head-nav">
            <li class="dropdown mega-dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" style="border-bottom-color:#ed1b24 ;" role="button" aria-expanded="false">BLANKET</a>

                  <ul class="dropdown-menu mega-dropdown-menu row">
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header red">ACRYLIC</li>
                           <li class='red1'><a href="#">2ply Blanket</a></li>
                           <li class='red1'><a href="#">Gold Digital</a></li>
                           <li class='red1'><a href="#">Harmony </a></li>
                           <li class='red1'><a href="#">Mora Gold</a></li>
                           <li class='red1'><a href="#">Mora Magic</a></li>
                           <li class="dropdown-header red">Elegance </li>
                           <li class='red1'><a href="#">Antartida </a></li>
                           <li class='red1'><a href="#">Kibo </a></li>
                           <li class='red1'><a href="#">Kolari </a></li>
                           <li class='red1'><a href="#">Laponia</a></li>
                           <li class='red1'><a href="#">Logan </a></li>
                           <li class='red1'><a href="#">Moscu</a></li>
                           <li class='red1'><a href="#">Venus Plus</a></li>
                           <li class='red1'><a href="#">YUKON</a></li>
                        </ul>
                     </li>
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header red">Single Blanket</li>
                            <li class='red1'><a href="#">Color</a></li>
                           <li class='red1'><a href="#">Color Printed </a></li>
                           <li class='red1'><a href="#">Gold Digital </a></li>
                           <li class='red1'><a href="#">Harmony </a></li>
                           <li class='red1'><a href="#">Mora Gold</a></li>
                           <li class='red1'><a href="#">Mora Sofing </a></li>
                           <li class='red1'><a href="#">Serena  </a></li>
                           <li class='red1'><a href="#">Topitos  </a></li>
                           <li class="dropdown-header red">Set 4 Piece </li>
                           <li class='red1'><a href="#">Mora Gold </a></li>
                           <li class='red1'><a href="#">Mora Gold Digital </a></li>
                          
                        </ul>
                     </li>
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header red">DOUBLE BLANKET </li>
                           <li class='red1'><a href="#">3D ART </a></li>
                           <li class='red1'><a href="#">Arabescco </a></li>
                           <li class='red1'><a href="#">Color </a></li>
                           <li class='red1'><a href="#">Gold Digital Embroidery </a></li>
                           <li class='red1'><a href="#">Imperial Embossed </a></li>
                           <li class='red1'><a href="#">Infinity </a></li>
                           <li class='red1'><a href="#">Luxury Blanket </a></li>
                           <li class='red1'><a href="#">Marble </a></li>
                           <li class='red1'><a href="#">Micro Coral </a></li>
                           <li class='red1'><a href="#">Mora Gold  </a></li>
                           <li class='red1'><a href="#">Mora Gold Digital </a></li>
                           <li class='red1'><a href="#">MORA MAGIC </a></li>
                           <li class='red1'><a href="#">Novalinea  </a></li>
                           <li class='red1'><a href="#">Serena  </a></li>
                           <li class='red1'><a href="#">Silver Ion </a></li>
                           <li class='red1'><a href="#">Topitos XL </a></li>
                           <li class='red1'><a href="#">Wedding Gift </a></li>
                        </ul>
                     </li>
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header red">FURS Collection </li>
                           <li class='red1'><a href="#">Antartida </a></li>
                           <li class='red1'><a href="#">Kibo </a></li>
                           <li class='red1'><a href="#">Kolari </a></li>
                           <li class='red1'><a href="#">Laponia</a></li>
                           <li class='red1'><a href="#">Logan </a></li>
                           <li class='red1'><a href="#">Moscu</a></li>
                           <li class='red1'><a href="#">Venus Plus</a></li>
                           <li class='red1'><a href="#">YUKON</a></li>
                           
                        </ul>
                     </li>
                  </ul>

               </li>
               <li class="dropdown mega-dropdown">
                  <a href="#" class="dropdown-toggle" style="border-bottom-color:#ed1b24 ;" data-toggle="dropdown" role="button" aria-expanded="false">PILLOWS </a>

                  <ul class="dropdown-menu mega-dropdown-menu row">
                     <li class="col-sm-12">
                        <ul >
                           <li class="dropdown-header red">Pillows</li>
                           <li class='red1'><a href="#">Baby Pillow </a></li>
                           <li class='red1'><a href="#">Luxury Pillow </a></li>
                           <li class='red1'><a href="#">Medicated Pillow </a></li>
                          
                        </ul>
                     </li>
                    
                  </ul>

               </li>
               <li class="dropdown mega-dropdown">
                  <a href="#" class="dropdown-toggle" style="border-bottom-color:#ed1b24 ;" data-toggle="dropdown" role="button" aria-expanded="false">BED SHEET</a>

                  <ul class="dropdown-menu mega-dropdown-menu row">
                     <li class="col-sm-12">
                        <ul>
                           <li class="dropdown-header red">BED SHEET</li>
                           <li class='red1'><a href="#">Single Bed Sheets</a></li>
                           <li class='red1'><a href="#">Double Bed Sheets</a></li>
                           <li class='red1'><a href="#">King Bed Sheets </a></li>
                           <li class='red1'><a href="#">Fitted Bed Sheets</a></li>
                        </ul>
                     </li>
                    
                  </ul>

               </li>
               <li class="dropdown mega-dropdown">
                  <a href="#" class="dropdown-toggle" style="border-bottom-color:#ed1b24 ;" data-toggle="dropdown" role="button" aria-expanded="false">CARPETS</a>

                  <ul class="dropdown-menu mega-dropdown-menu row">
                     <li class="col-sm-12">
                        <ul>
                           <li class="dropdown-header red">CARPETS</li>
                           <li class='red1'><a href="#">Oriental Carpets</a></li>
                           <li class='red1'><a href="#">Plush Carpets</a></li>
                           <li class='red1'><a href="#">Shag Carpets </a></li>
                           <li class='red1'><a href="#">Cut Pile Carpets</a></li>
                           <li class='red1'><a href="#">Loop Pile Carpets</a></li>
                           <li class='red1'><a href="#">Cut & Loop Carpets </a></li>
                           <li class='red1'><a href="#">Flatweave Carpets</a></li>
                        </ul>
                     </li>
                    
                  </ul>

               </li>
          
            </ul>
            
            
            <ul class="nav navbar-nav navbar-right">
            <li>
               <form class="form-inline search-form">
             
             <input class="form-control search-input rounded-0 border-dark border-right-0" type="search" placeholder="Search for products, brands and more" aria-label="Search">
             <button class="btn btn-light search-btn border-left-0 border-dark rounded-0" type="submit">
                <i class="fa fa-search text-secondary "></i>
             </button>
          </form>
              </li>
          
            <li class="dropdown mega-dropdown">
                
                  <a href="#" class="dropdown-toggle" style="border-bottom-color:#ed1b24 ;" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                            <i class="fa fa-user"></i>
                            Account & Lists 
                        </a>
                  <ul class="dropdown-menu mega-dropdown-menu row accountlist">
                     
                     <li class="col-sm-6">
                        <ul>
                           <li class="dropdown-header red">Your List</li>
                           <li class='red1'><a href="#">Wishlist</a></li>
                           <li class='red1'><a href="#">Payment History</a></li>
                           <li class='red1'><a href="#">Your Dabbous Membership </a></li>
                           <li class='red1'><a href="#">Your Dabbous bussiness card</a></li>
                           <li class='red1'><a href="#">Your Dabbous Rewards Points</a></li>
                        </ul>
                     </li>
                     <li class="col-sm-6">
                        <ul>
                           <li class="dropdown-header red">Your Account</li>
                            <li class='red1'><a href="#">Account</a></li>
                           <li class='red1'><a href="#">Your Order</a></li>
                           <li class='red1'><a href="#">Saved cards </a></li>
                           <li class='red1'><a href="#">Delivery Address</a></li>
                           <li class='red1'><a href="#">Sign out</a></li>

                        </ul>
                     </li>
                  </ul>

               </li>
                    <li >
                        <a href="#"  style="border:none;">
                        <i class="fa fa-shopping-cart">
                               
                            </i>
                            Order Track
                        </a>
                        
                    </li>
                    <li>
                    <a href="./cart.php"  style="border:none;">
                    <i class="fa fa-shopping-bag">
                                <span class="badge badge-danger">1</span>
                            </i>
                            AddToCart
                        </a>
                  </li>
                  <li>
                    <a href="#"  style="border:none;">
                    <i class="glyphicon glyphicon-bookmark"></i>
                    Wishlist
                        </a>
                  </li>
                  <li class="dropdown mega-dropdown">
            
            <a href="#" class="dropdown-toggle" style="border-bottom-color:#ed1b24 ;" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                      <i class="fa fa-language"></i>
                      Langugae  
                  </a>
            <ul class="dropdown-menu mega-dropdown-menu row accountlist smalldropsize" style="display: none;">
               
               <li  class="col-sm-12">
                  <ul > 
                     <li class="dropdown-header red">Langugae</li>
                     <li class="red1"><a href="#">English</a></li>
                      <li class="red1"><a href="#">Arabic</a></li>
                  </ul>
               </li>
            </ul>

         </li>
               </ul>
          
         </div>
         <!-- /.nav-collapse -->
      </nav>
</div>
</div>