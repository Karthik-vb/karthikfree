<htmL>
<head>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<link rel="stylesheet" href="mega-menu.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script src="mega-menu.js"></script>
<script>
$(document).ready(function(){
	$('.carousel').carousel({
    pause: "false"
});
	$("#carousel-1,#carousel-2,#carousel-3,#carousel-4,#carousel-5,#carousel-6").hide();
$(".sectionbox1").bind('mouseover',function(event){
	$("#box1").hide();
	$("#carousel-1").show();

});
$('.sectionbox1').bind('mouseleave', function(e) {
	$("#carousel-1").hide();
	$("#box1").show();
	
});
$(".sectionbox2").bind('mouseover',function(event){
	$("#box2").hide();
	$("#carousel-2").show();

});
$('.sectionbox2').bind('mouseleave', function(e) {
	$("#carousel-2").hide();
	$("#box2").show();
	
});
$(".sectionbox3").bind('mouseover',function(event){
	$("#box3").hide();
	$("#carousel-3").show();

});
$('.sectionbox3').bind('mouseleave', function(e) {
	$("#carousel-3").hide();
	$("#box3").show();
	
});
$(".sectionbox4").bind('mouseover',function(event){
	$("#box4").hide();
	$("#carousel-4").show();

});
$('.sectionbox4').bind('mouseleave', function(e) {
	$("#carousel-4").hide();
	$("#box4").show();
	
});
$(".sectionbox5").bind('mouseover',function(event){
	$("#box5").hide();
	$("#carousel-5").show();

});
$('.sectionbox5').bind('mouseleave', function(e) {
	$("#carousel-5").hide();
	$("#box5").show();
	
});
$(".sectionbox6").bind('mouseover',function(event){
	$("#box6").hide();
	$("#carousel-6").show();

});
$('.sectionbox6').bind('mouseleave', function(e) {
	$("#carousel-6").hide();
	$("#box6").show();
	
});
});
</script>
<style>
	.panel-heading {
  padding: 15px 15px !important;
}
	.accordion-toggle:hover {
  text-decoration: none !important;
}
input[type="checkbox"],
input[type="radio"] {
  margin-top: 0px !important;
  line-height: normal;
 
}
.checkbox label,.radio label
{
	font-size: 15px!important;
}
.slide
{
	margin-top:0px!important;
}
.thumbnail
{
	opacity:1!important;
	border:0px!important;
}
.search-form1 .form-group {
  float: right !important;
  transition: all 0.35s, border-radius 0s;
  width: 32px;
  height: 32px;
  background-color: #fff;
  box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset;
  margin-top: -23px;
  border-radius: 25px;
  border: 1px solid #ccc;
}
.search-form1 .form-group input.form-control {
  padding-right: 20px;
  border: 0 none;
  background: transparent;
  box-shadow: none;
  display:block;
}
.search-form1 .form-group input.form-control::-webkit-input-placeholder {
  display: none;
}
.search-form1 .form-group input.form-control:-moz-placeholder {
  /* Firefox 18- */
  display: none;
}
.search-form1 .form-group input.form-control::-moz-placeholder {
  /* Firefox 19+ */
  display: none;
}
.search-form1 .form-group input.form-control:-ms-input-placeholder {
  display: none;
}
.search-form1 .form-group:hover,
.search-form1 .form-group.hover {
  width: 100%;
  border-radius: 4px 25px 25px 4px;
}
.search-form1 .form-group span.form-control-feedback {
  position: absolute;
  top: -1px;
  right: -2px;
  z-index: 2;
  display: block;
  width: 34px;
  height: 34px;
  line-height: 34px;
  text-align: center;
  color: #3596e0;
  left: initial;
  font-size: 14px;
}
	</style>
</head>
<body>
<div class="container-fluid no-padding">
<?php include("./header.php"); ?>
<div class="container-fluid" style="margin-top:80px;padding:50px">
    <div class="row">
        <div class="col">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="./index.php">Home</a></li>
                    <li class="breadcrumb-item"><a href="./subcategory.php?category=1">Category</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo $_GET['category'];?></li>
                </ol>
            </nav>
        </div>
	</div>
	<div class="row">
	<div class="col-lg-3">
	<div class="primary">
        <div class="filter-menu">
          <form>
            <div class="panel panel-default">
              <div class="panel-heading">
              
                <div class="panel-title hidden-sm">
                  Filter
                </div><!-- /.panel-title -->
                <div class="panel-body">
                  <button class="btn btn-default">Apply Filters</button>
                  <a class="btn btn-sm btn-default pull-right hidden-sm" href="#">Reset</a>
                </div><!-- /.panel-body -->
              </div><!-- /.panel-heading -->

              <div class="panel-body">
                <div class="panel-group" id="filter-menu" role="tablist" aria-multiselectable="true">
                  <div class="panel panel-default">
                    <div class="panel-heading" role="tab" id="headingOne">
                      <a class="panel-title accordion-toggle" role="button" data-toggle="collapse" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
					  Categories
                      </a><!-- /.panel-title -->
					  <div class="search-form1">
                <div class="form-group has-feedback">
            		<label for="search" class="sr-only">Search</label>
            		<input type="text" class="form-control" name="search" id="search" placeholder="search">
              		<span class="glyphicon glyphicon-search form-control-feedback"></span>
            	</div>
            </div>
                    </div><!-- /.panel-heading -->
                    <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                      <div class="panel-body">
                        <div class="checkbox"><label><input type="checkbox" name="career_state[]" value="recent_graduate">Blanket</label> <span class="brand-num">(1163)</span></div>
                        <div class="checkbox"><label><input type="checkbox" name="career_state[]" value="imposter_syndrome">Quilt</label><span class="brand-num">(1263)</span></div>
						<div class="checkbox"><label><input type="checkbox" name="career_state[]" value="wise_old_head">Bed Sheet</label><span class="brand-num">(1463)</span></div>
						<div class="checkbox"><label><input type="checkbox" name="career_state[]" value="wise_old_head">Pillows</label><span class="brand-num">(1663)</span></div>
						<div class="checkbox"><label><input type="checkbox" name="career_state[]" value="wise_old_head">Carpets</label><span class="brand-num">(1123)</span></div>
						<div class="categories-more">+ 290 more</div>
                      </div><!-- /.panel-body -->
                    </div><!-- /.panel-collapse -->
                  </div><!-- /.panel -->

                  <div class="panel panel-default">
                    <div class="panel-heading" role="tab" id="headingTwo">
                      <a class="panel-title accordion-toggle collapsed" role="button" data-toggle="collapse" href="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                        Brand
					  </a><!-- /.panel-title -->
					  <div class="search-form1">
                <div class="form-group has-feedback">
            		<label for="search" class="sr-only">Search</label>
            		<input type="text" class="form-control" name="search" id="search" placeholder="search">
              		<span class="glyphicon glyphicon-search form-control-feedback"></span>
            	</div>
            </div>
                    </div><!-- /.panel-heading -->
                    <div id="collapseTwo" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingTwo">
                      <div class="panel-body">
                        <div class="checkbox"><label><input type="checkbox" name="topic[]" value="politics">Mora Spain <span class="brand-num">(2163)</span></label></div>
                        <div class="checkbox"><label><input type="checkbox" name="topic[]" value="religion">Stitching Brand<span class="brand-num">(1963)</span></label></div>
                        <div class="checkbox"><label><input type="checkbox" name="topic[]" value="music">Thomaston Mills<span class="brand-num">(1563)</span></label></div>
						<div class="categories-more">+ 90 more</div>
					  </div><!-- /.panel-body -->
                    </div><!-- /.panel-collapse -->
                  </div><!-- /.panel -->

                  <div class="panel panel-default">
                    <div class="panel-heading" role="tab" id="headingThree">
                      <a class="panel-title accordion-toggle collapsed" role="button" data-toggle="collapse" href="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
                        Price
                      </a><!-- /.panel-title -->
                    </div><!-- /.panel-heading -->
                    <div id="collapseThree" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingThree">
                      <div class="panel-body">
                        <div class="checkbox"><label><input type="checkbox" name="format[]" value="magazine">₹200 to ₹800 <span class="brand-num">(1363)</span></label></div>
                        <div class="checkbox"><label><input type="checkbox" name="format[]" value="website">₹801 to ₹1,600 <span class="brand-num">(1463)</span></label></div>
                        <div class="checkbox"><label><input type="checkbox" name="format[]" value="vine">₹1,601 to ₹2,400 <span class="brand-num">(1563)</span></label></div>
                        <div class="checkbox"><label><input type="checkbox" name="format[]" value="tweet">₹2,401 to ₹3,000 (Above)<span class="brand-num">(1763)</span></label></div>
                      </div><!-- /.panel-body -->
                    </div><!-- /.panel-collapse -->
                  </div><!-- /.panel -->

                  <div class="panel panel-default">
                    <div class="panel-heading" role="tab" id="headingFour">
                      <a class="panel-title accordion-toggle collapsed" role="button" data-toggle="collapse" href="#collapseFour" aria-expanded="true" aria-controls="collapseFour">
                        Color
					  </a><!-- /.panel-title -->
					  <div class="search-form1">
                <div class="form-group has-feedback">
            		<label for="search" class="sr-only">Search</label>
            		<input type="text" class="form-control" name="search" id="search" placeholder="search">
              		<span class="glyphicon glyphicon-search form-control-feedback"></span>
            	</div>
            </div>
                    </div><!-- /.panel-heading -->
                    <div id="collapseFour" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingFour">
                      <div class="panel-body">
                        <div class="checkbox"><label><input type="checkbox" name="status[]" value="single"><span data-colorhex="black" class="colour-label colour-colorDisplay" style="background-color: rgb(54, 69, 79);"></span> Black<span class="brand-num">(1363)</span></label></div>
                        <div class="checkbox"><label><input type="checkbox" name="status[]" value="married"><span data-colorhex="blue" class="colour-label colour-colorDisplay" style="background-color: rgb(0, 116, 217);"></span> Blue<span class="brand-num">(2163)</span></label></div>
						<div class="checkbox"><label><input type="checkbox" name="status[]" value="its_complicated"><span data-colorhex="red" class="colour-label colour-colorDisplay" style="background-color: rgb(211, 75, 86);"></span> red<span class="brand-num">(3163)</span></label></div>
						<div class="checkbox"><label><input type="checkbox" name="status[]" value="its_complicated"><span data-colorhex="navy blue" class="colour-label colour-colorDisplay" style="background-color: rgb(60, 68, 119);"></span> Navy Blue<span class="brand-num">(163)</span></label></div>
						<div class="checkbox"><label><input type="checkbox" name="status[]" value="its_complicated"><span data-colorhex="white" class="colour-label colour-colorDisplay" style="background-color: rgb(255, 255, 255);"></span> White<span class="brand-num">(4163)</span></label></div>
						<div class="checkbox"><label><input type="checkbox" name="status[]" value="its_complicated"><span data-colorhex="grey" class="colour-label colour-colorDisplay" style="background-color: rgb(159, 168, 171);"></span> Grey<span class="brand-num">(4163)</span></label></div>
						<div class="checkbox"><label><input type="checkbox" name="status[]" value="its_complicated"><span data-colorhex="pink" class="colour-label colour-colorDisplay" style="background-color: rgb(241, 169, 196);"></span> Pink<span class="brand-num">(4163)</span></label></div>
						<div class="categories-more">+ 40 more</div>
					  </div><!-- /.panel-body -->
                    </div><!-- /.panel-collapse -->
                  </div><!-- /.panel -->
				  <div class="panel panel-default">
                    <div class="panel-heading" role="tab" id="headingThree">
                      <a class="panel-title accordion-toggle collapsed" role="button" data-toggle="collapse" href="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
					  DISCOUNT RANGE
                      </a><!-- /.panel-title -->
                    </div><!-- /.panel-heading -->
                    <div id="collapseThree" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingThree">
                      <div class="panel-body">
                        <div class="radio"><label><input type="radio" name="format[]" value="magazine">10% and above </label></div>
                        <div class="radio"><label><input type="radio" name="format[]" value="website">20% and above </label></div>
                        <div class="radio"><label><input type="radio" name="format[]" value="vine">30% and above </label></div>
                        <div class="radio"><label><input type="radio" name="format[]" value="tweet">40% and above</label></div>
						<div class="radio"><label><input type="radio" name="format[]" value="magazine">50% and above </label></div>
                        <div class="radio"><label><input type="radio" name="format[]" value="website">60% and above </label></div>
                        <div class="radio"><label><input type="radio" name="format[]" value="vine">70% and above </label></div>
                        <div class="radio"><label><input type="radio" name="format[]" value="tweet">80% and above</label></div>
                      </div><!-- /.panel-body -->
                    </div><!-- /.panel-collapse -->
                  </div><!-- /.panel -->
                </div><!-- /.panel-group -->
              </div><!-- /.panel-body -->

            </div><!-- /.panel -->
          </form>
        </div><!-- /.filter-menu -->        
      </div>
	  </div>
	  <div class="col-lg-9">
	<?php if($_GET['category']=='ACRYLIC'){ ?>
		<div class="row">
	
	<!-- BEGIN PRODUCTS -->
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
	  <a href="./details.php?name=2plyBlanket&prize=₹17,375&cprize=₹17,800.00" >
		<span class="thumbnail">
			 <div class="section-box-eleven sectionbox1">
                   
                    <figure> 
                        <!-- <a href="./details.php?name=2plyBlanket&prize=₹17,375" class="btn pull-left"><i class="fa fa-eye"></i></a>
                        <a href="#" class="btn pull-right"><i class="fa fa-shopping-cart"></i></a> -->
						<span class="product-actionsButton product-wishlist " style="width: 100%; text-align: center;">wishlist</span>
			  <h4>2ply Blanket</h4>
			  <p>Size :  240 × 270 cm</p> 
			  <hr class="line">
			    <div class="product-price"><span><span class="product-discountedPrice">₹17,375.00</span><span class="product-strike">₹17,800.00</span></span><span class="product-discountPercentage">(5% OFF)</span></div>
                    </figure  >
                     <!-- <img class="img-responsive box-img1" src="./images/2Ply1.jpg" alt="..."> -->
					 <div id="carousel-1"  class="carousel slide slide-carousel"  data-ride="carousel" data-interval="500">
              <!-- Indicators -->
              <ol class="carousel-indicators box-indicators">
                <li data-target="#carousel-1" data-slide-to="0" class="active"></li>
                <li data-target="#carousel-1" data-slide-to="1"></li>
                <li data-target="#carousel-1" data-slide-to="2"></li>
              </ol>
            
              <!-- Wrapper for slides -->
              <div class="carousel-inner">
                <div class="item active">
                    <img class="img-responsive box-img2" src="./images/2Ply1.jpg" alt="Image">
                </div>
                <div class="item">
                    <img class="img-responsive box-img2" src="./images/2Ply1.jpg" alt="Image">
                </div>
                <div class="item">
                    <img class="img-responsive box-img2" src="./images/2Ply1.jpg" alt="Image">
                </div>
              </div>
            </div>
			<img class="img-responsive box-img2" id="box1" src="./images/2Ply1.jpg" alt="Image">
			<h4>2ply Blanket</h4>
			<p>2ply Blanket is a range of prime quality blankets</p>
			<div class="product-price"><span><span class="product-discountedPrice">₹17,375.00</span><span class="product-strike">₹17,800.00</span></span><span class="product-discountPercentage">(5% OFF)</span></div>
			</div>
		</span>
		</a>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
	  <a href="./details.php?name=GoldDigital&prize=₹17,375&cprize=₹17,800.00" >
		<span class="thumbnail">
		<div class="section-box-eleven sectionbox2">
                   
				   <figure>
					   <!-- <a href="./details.php?name=GoldDigital&prize=₹17,375" class="btn pull-left"><i class="fa fa-eye"></i></a> -->
					   <span class="product-actionsButton product-wishlist " style="width: 100%; text-align: center;">wishlist</span>
					   <h4>Gold Digital</h4>
					   <p>Size :  240 × 270 cm</p>
					   <hr class="line">
					   <div class="product-price"><span><span class="product-discountedPrice">₹17,375.00</span><span class="product-strike">₹17,800.00</span></span><span class="product-discountPercentage">(5% OFF)</span></div>
				   </figure>
				   <div id="carousel-2"  class="carousel slide slide-carousel"  data-ride="carousel" data-interval="500">
              <!-- Indicators -->
              <ol class="carousel-indicators box-indicators">
                <li data-target="#carousel-2" data-slide-to="0" class="active"></li>
                <li data-target="#carousel-2" data-slide-to="1"></li>
                <li data-target="#carousel-2" data-slide-to="2"></li>
              </ol>
            
              <!-- Wrapper for slides -->
              <div class="carousel-inner">
                <div class="item active">
                    <img class="img-responsive box-img2" src="./images/MGold1.jpg" alt="Image">
                </div>
                <div class="item">
                    <img class="img-responsive box-img2" src="./images/MGold1.jpg" alt="Image">
                </div>
                <div class="item">
                    <img class="img-responsive box-img2" src="./images/MGold1.jpg" alt="Image">
                </div>
              </div>
            </div>
				   <img  class="img-responsive box-img2" id="box2" src="./images/MGold1.jpg" alt="...">
			  <h4>Gold Digital</h4>
			  <p>Gold Digital is a range of prime quality blankets. </p>
			  <div class="product-price"><span><span class="product-discountedPrice">₹17,375.00</span><span class="product-strike">₹17,800.00</span></span><span class="product-discountPercentage">(5% OFF)</span></div>
			  </div>
		</span>
		</a>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
	  <a href="./details.php?name=Harmony&prize=₹7,625&cprize=₹8,000.00">
		<span class="thumbnail">
		<div class="section-box-eleven sectionbox3">
                   
				   <figure>
					   <!-- <a href="./details.php?name=Harmony&prize=₹7,625" class="btn pull-left"><i class="fa fa-eye"></i></a> -->
					   <span class="product-actionsButton product-wishlist " style="width: 100%; text-align: center;">wishlist</span>
					   <h4>Harmony</h4>
					  <p>Size :  240 × 270 cm</p>
					  <hr class="line">
					  <div class="product-price"><span><span class="product-discountedPrice">₹7,625.00</span><span class="product-strike">₹8,000.00</span></span><span class="product-discountPercentage">(5% OFF)</span></div>
				   </figure>
				   <div id="carousel-3"  class="carousel slide slide-carousel"  data-ride="carousel" data-interval="500">
              <!-- Indicators -->
              <ol class="carousel-indicators box-indicators">
                <li data-target="#carousel-3" data-slide-to="0" class="active"></li>
                <li data-target="#carousel-3" data-slide-to="1"></li>
                <li data-target="#carousel-3" data-slide-to="2"></li>
              </ol>
            
              <!-- Wrapper for slides -->
              <div class="carousel-inner">
                <div class="item active">
                    <img class="img-responsive box-img2" src="./images/2Ply2.jpg" alt="Image">
                </div>
                <div class="item">
                    <img class="img-responsive box-img2" src="./images/2Ply2.jpg" alt="Image">
                </div>
                <div class="item">
                    <img class="img-responsive box-img2" src="./images/2Ply2.jpg" alt="Image">
                </div>
              </div>
            </div>
				   <img class="img-responsive box-img2" id="box3" src="./images/2Ply2.jpg" alt="...">
			   
			
			  <h4>Harmony</h4>
			  <p>Harmony is a range of premium blankets. </p>
			  <div class="product-price"><span><span class="product-discountedPrice">₹7,625.00</span><span class="product-strike">₹8,000.00</span></span><span class="product-discountPercentage">(5% OFF)</span></div>
			  </div>
		</span>
		</a>
	</div>
	<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
	<a href="./details.php?name=MoraGold&prize=₹16,625&cprize=₹17,000.00">
		<span class="thumbnail">
		<div class="section-box-eleven sectionbox4">
                   
				   <figure>
					   <!-- <a href="./details.php?name=MoraGold&prize=₹16,625" class="btn pull-left"><i class="fa fa-eye"></i></a> -->
					   <span class="product-actionsButton product-wishlist " style="width: 100%; text-align: center;">wishlist</span>
					   
			  <h4>Mora Gold</h4>
			  <p>Size :  240 × 270 cm</p>
			  <hr class="line">
			  <div class="product-price"><span><span class="product-discountedPrice">₹16,625.00</span><span class="product-strike">₹17,000.00</span></span><span class="product-discountPercentage">(5% OFF)</span></div>
				   </figure>
				   <div id="carousel-4"  class="carousel slide slide-carousel"  data-ride="carousel" data-interval="500">
              <!-- Indicators -->
              <ol class="carousel-indicators box-indicators">
                <li data-target="#carousel-4" data-slide-to="0" class="active"></li>
                <li data-target="#carousel-4" data-slide-to="1"></li>
                <li data-target="#carousel-4" data-slide-to="2"></li>
              </ol>
            
              <!-- Wrapper for slides -->
              <div class="carousel-inner">
                <div class="item active">
                    <img class="img-responsive box-img2" src="./images/Mora-Gold1.jpg" alt="Image">
                </div>
                <div class="item">
                    <img class="img-responsive box-img2" src="./images/Mora-Gold1.jpg" alt="Image">
                </div>
                <div class="item">
                    <img class="img-responsive box-img2" src="./images/Mora-Gold1.jpg" alt="Image">
                </div>
              </div>
            </div>
				   <img class="img-responsive box-img2" id="box4" src="./images/Mora-Gold1.jpg" alt="...">
			  
			  <h4>Mora Gold</h4>
			  <p>Gold is a range of premium blankets .</p>
			  <div class="product-price"><span><span class="product-discountedPrice">₹16,625.00</span><span class="product-strike">₹17,000.00</span></span><span class="product-discountPercentage">(5% OFF)</span></div>
			 
			  </div>
		</span>
		</a>
	</div>
   
	
  
	 </div>
	 <div class="row">
	
	<!-- BEGIN PRODUCTS -->
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
	  <a href="./details.php?name=MoraMagic&prize=₹16,000&cprize=₹16,800.00" >
		<span class="thumbnail">
		<div class="section-box-eleven sectionbox5">
                   
				   <figure>
					   <!-- <a href="./details.php?name=MoraMagic&prize=₹16,000" class="btn pull-left"><i class="fa fa-eye"></i></a> -->
					   <span class="product-actionsButton product-wishlist " style="width: 100%; text-align: center;">wishlist</span>
					   <h4>Mora Magic</h4>
			  <p>Size :  240 × 270 cm</p>
			  <hr class="line">
			  <div class="product-price"><span><span class="product-discountedPrice">₹16,000.00</span><span class="product-strike">Rs.16,800</span></span><span class="product-discountPercentage">(5% OFF)</span></div>
				   </figure>
				   <div id="carousel-5"  class="carousel slide slide-carousel"  data-ride="carousel" data-interval="500">
              <!-- Indicators -->
              <ol class="carousel-indicators box-indicators">
                <li data-target="#carousel-5" data-slide-to="0" class="active"></li>
                <li data-target="#carousel-5" data-slide-to="1"></li>
                <li data-target="#carousel-5" data-slide-to="2"></li>
              </ol>
            
              <!-- Wrapper for slides -->
              <div class="carousel-inner">
                <div class="item active">
                    <img class="img-responsive box-img2" src="./images/MORA-MAGIC1.jpg" alt="Image">
                </div>
                <div class="item">
                    <img class="img-responsive box-img2" src="./images/MORA-MAGIC1.jpg" alt="Image">
                </div>
                <div class="item">
                    <img class="img-responsive box-img2" src="./images/MORA-MAGIC1.jpg" alt="Image">
                </div>
              </div>
            </div>
				   <img class="img-responsive box-img2" id="box5" src="./images/MORA-MAGIC1.jpg" alt="...">
			  <h4>Mora Magic</h4>
			  <p>Magic is a range of premium blankets  </p>
			  <div class="product-price"><span><span class="product-discountedPrice">₹16,000.00</span><span class="product-strike">Rs.16,800</span></span><span class="product-discountPercentage">(5% OFF)</span></div>
			  </div>
		</span>
		</a>
	  </div>
	 
</div>
<?php } ?>
<?php if($_GET['category']=='DOUBLEBLANKET'){ ?>
		<div class="row">
	
	<!-- BEGIN PRODUCTS -->
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1"> 
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/3D-ART.jpg" alt="...">
			  <h4>3D ART</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img  class="img-responsive box-img1" src="./images/Arabesco.jpg" alt="...">
			  <h4>Arabescco</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
		   <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Mora-Color.jpg" alt="...">
			  <h4>Color </h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			  <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	</div>
	<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/MG_Digital_Embroidery.jpg" alt="...">
			  <h4>Gold Digital Embroidery</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			  <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	</div>
   
	
  
	 </div>
	 <div class="row">
	
	<!-- BEGIN PRODUCTS -->
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/MoraImperialEmbossed.jpg" alt="...">
			  <h4>Imperial Embossed</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	 
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img  class="img-responsive box-img1" src="./images/INFINITY.jpg" alt="...">
			  <h4>Infinity </h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
		   <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Mora_luxury_Plus.jpg" alt="...">
			  <h4>Luxury Blanket </h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			  <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	</div>
	<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Marble.jpg" alt="...">
			  <h4>Marble</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			  <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	</div>
	
  
	 </div>
	 <div class="row">
	
	<!-- BEGIN PRODUCTS -->
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/MicroCoral.jpg" alt="...">
			  <h4>Micro Coral</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	 
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img  class="img-responsive box-img1" src="./images/Mora-Gold_1.jpg" alt="...">
			  <h4>Mora Gold  </h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
		   <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/MGold_Digital_1.jpg" alt="...">
			  <h4>Mora Gold Digital  </h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			  <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	</div>
	<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/MORA-MAGIC_1.jpg" alt="...">
			  <h4>MORA MAGIC</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			  <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	</div>
	
  
	 </div>
	 <div class="row">
	
	<!-- BEGIN PRODUCTS -->
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Sofing.jpg" alt="...">
			  <h4>Mora Sofing</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	 
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img  class="img-responsive box-img1" src="./images/NovaLinea.jpg" alt="...">
			  <h4>Novalinea  </h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
		   <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Serena.jpg" alt="...">
			  <h4>Serena  </h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			  <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	</div>
	<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/silver1.jpg" alt="...">
			  <h4>Silver Ion</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			  <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	</div>
	
  
	 </div>
	 <div class="row">
	
	<!-- BEGIN PRODUCTS -->
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Topitos1.jpg" alt="...">
			  <h4>Topitos XL</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	 
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img  class="img-responsive box-img1" src="./images/gift.jpg" alt="...">
			  <h4>Wedding Gift</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
		   <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  </div>
<?php } ?>
<?php if($_GET['category']=='Set4Piece'){ ?>
		<div class="row">
	
	<!-- BEGIN PRODUCTS -->
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/MGold_1.jpg" alt="...">
			  <h4>Mora Gold</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img  class="img-responsive box-img1" src="./images/MGold_Digital_2.jpg" alt="...">
			  <h4>Mora Gold Digital</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
		   <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	 
	
  
	 </div>
<?php } ?>
<?php if($_GET['category']=='SingleBLANKET'){ ?>
		<div class="row">
	
	<!-- BEGIN PRODUCTS -->
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Mora-Color_1.jpg" alt="...">
			  <h4>Color</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img  class="img-responsive box-img1" src="./images/MoraColor_1.jpg" alt="...">
			  <h4>Color Printed</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
		   <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/MGold_Digital_3.jpg" alt="...">
			  <h4>Gold Digital</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			  <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	</div>
	<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Harmony_1.jpg" alt="...">
			  <h4>Harmony </h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			  <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	</div>
   
	
  
	 </div>
	 <div class="row">
	
	<!-- BEGIN PRODUCTS -->
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/MoraGold_01.jpg" alt="...">
			  <h4>Mora Gold</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	 
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Sofing_01.jpg" alt="...">
			  <h4>Mora Sofing</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/SERENA_02.jpg" alt="...">
			  <h4>Serena </h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Topitos_1.jpg" alt="...">
			  <h4>Topitos </h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	
  
	 </div>
<?php } ?>
<?php if($_GET['category']=='FURSCollection'){ ?>
		<div class="row">
	
	<!-- BEGIN PRODUCTS -->
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/ANTARTIDA.jpg" alt="...">
			  <h4>Antartida</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img  class="img-responsive box-img1" src="./images/kibo.jpg" alt="...">
			  <h4>Kibo</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
		   <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Kolari.jpg" alt="...">
			  <h4>Kolari </h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			  <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	</div>
	<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Laponia.jpg" alt="...">
			  <h4>Laponia</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			  <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	</div>
   
	
  
	 </div>
	 <div class="row">
	
	<!-- BEGIN PRODUCTS -->
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/LOGAN_1.jpg" alt="...">
			  <h4>Logan </h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	 
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Moscú.jpg" alt="...">
			  <h4>Moscu </h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Venus-Plus.jpg" alt="...">
			  <h4>Venus Plus </h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/YUKON.jpg" alt="...">
			  <h4>YUKON </h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	
  
	 </div>
<?php } ?>
<?php if($_GET['category']=='Elegance'){ ?>
		<div class="row">
	
	<!-- BEGIN PRODUCTS -->
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/YUKON_1.jpg" alt="...">
			  <h4>YUKON</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img  class="img-responsive box-img1" src="./images/kibo1.jpg" alt="...">
			  <h4>KIBO</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
		   <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/LOGAN_G0.jpg" alt="...">
			  <h4>LOGAN</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			  <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	</div>
	<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/ANTARTIDA1.jpg" alt="...">
			  <h4>ANTARTIDA</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			  <div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	</div>
   
	
  
	 </div>
	 <div class="row">
	
	<!-- BEGIN PRODUCTS -->
	  <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Venus-Plus_1.jpg" alt="...">
			  <h4>Venus Plus Blanket</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	 <!-- BEGIN PRODUCTS -->
	 <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Laponia1.jpg" alt="...">
			  <h4>Laponia Blanket</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
   <!-- BEGIN PRODUCTS -->
   <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Kolari_1.jpg" alt="...">
			  <h4>Kolari Blanket</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
	<!-- BEGIN PRODUCTS -->
	<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<span class="thumbnail">
			  <img class="img-responsive box-img1" src="./images/Moscú1.jpg" alt="...">
			  <h4>Moscu Blanket</h4>
			  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			  <hr class="line">
			<div class="row">
				  <div class="col-md-6 col-sm-6">
			  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
				  </div>
				  <div class="col-md-6 col-sm-6">
				   <a href="#" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
				  
			</div>
			  </div>
		</span>
	  </div>
  
	 </div>
<?php } ?>
<?php if($_GET['category']=='SummerQuilts'){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/Colcha.jpg" alt="...">
      			<h4>Colcha</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
                <div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
  		</div>
  	
  	
		 </div>
<?php } ?>
        
<?php if($_GET['category']=='SingleBedSheets'){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/image15.jpeg" alt="...">
      			<h4>Bed Sheet - شرشف</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
                <div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
  		</div>
  		
        
  	
		 </div>
<?php } ?>
<?php if($_GET['category']=='DoubleBedSheets'){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/image15.jpeg" alt="...">
      			<h4>Double Bed Sheets</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
                <div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
  		</div>
  		
        
  	
		 </div>
<?php } ?> 
<?php if($_GET['category']=='KingBedSheets'){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/image15.jpeg" alt="...">
      			<h4>King Bed Sheets</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
                <div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
  		</div>
  		
        
  	
		 </div>
<?php } ?> 
<?php if($_GET['category']=='FittedBedSheets'){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/image15.jpeg" alt="...">
      			<h4>Fitted Bed Sheets</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
                <div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
  		</div>
  		
        
  	
		 </div>
<?php } ?>     
<?php if($_GET['category']=='BabyPillow'){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/Baby-Pillow1.jpg" alt="...">
      			<h4>Baby Pillow</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
                <div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
  		</div>
  	
        
  	
		 </div>
<?php } ?>  
<?php if($_GET['category']=='LuxuryPillow'){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/luxplus_pillow1.jpg" alt="...">
      			<h4>Luxury Pillow</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
      			<div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
        </div>
        
  	
		 </div>
<?php } ?>  
<?php if($_GET['category']=='MedicatedPillow'){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/biogreen.jpg" alt="...">
      			<h4>Medicated Pillow</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
      			<div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
        </div>
        
  	
		 </div>
<?php } ?>  
<?php if($_GET['category']=='OrientalCarpets'){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/carpet4.jpeg" alt="...">
      			<h4>Oriental Carpets</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
                <div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
  		</div>
        
  	
		 </div>
<?php } ?>  
<?php if($_GET['category']=='PlushCarpets'){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img  class="img-responsive box-img1" src="./images/carpet1.jpeg" alt="...">
      			<h4>Plush Carpets</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
               <div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
  		</div>
  	
		 </div>
<?php } ?> 
<?php if($_GET['category']=='ShagCarpets'){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/carpet2.jpeg" alt="...">
      			<h4>Shag Carpets</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
      			<div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
        </div>
  	
		 </div>
<?php } ?> 
<?php if($_GET['category']=='CutPileCarpets'){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/carpet3.jpeg" alt="...">
      			<h4>Cut Pile Carpets</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
      			<div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
        </div>
  	
		 </div>
<?php } ?> 
<?php if($_GET['category']=='LoopPileCarpets'){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/carpet2.jpeg" alt="...">
      			<h4>Loop Pile Carpets</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
      			<div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
        </div>
  	
		 </div>
<?php } ?> 
<?php if($_GET['category']=='CutLoopCarpets'){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img  class="img-responsive box-img1" src="./images/carpet1.jpeg" alt="...">
      			<h4>Cut&Loop Carpets</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
               <div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
  		</div>
  	
		 </div>
<?php } ?> 
<?php if($_GET['category']=='FlatweaveCarpets'){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/carpet2.jpeg" alt="...">
      			<h4>Flat weave Carpets</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
      			<div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
        </div>
  	
		 </div>
<?php } ?> 
</div>
</div>
</div>

<?php include("./footer.php"); ?>
</div>
</body>
</html>