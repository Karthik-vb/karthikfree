<htmL>
<head>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<link rel="stylesheet" href="mega-menu.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script src="mega-menu.js"></script>
<style>

/* p {
    font-size: 16px;
    font-family: "Cairo", sans-serif;
    color: #837e7e;
    font-weight: 400;
    line-height: 26px;
    margin: 0 0 15px 0;
} */
.spad
{
    margin-top:100px;
    margin-bottom:50px;
}
.wrapper {
    /* padding: 50px 50px; */
    max-width: 1200px;
    text-align: center;
    margin-left: auto;
    margin-right: auto;
}

.right {float: right !important;}
/* Image zoom on hover + Overlay colour */
.parent {
    width: 400px;
    margin: 20px;
    height: 540px;
   
    overflow: hidden;
    position: relative;
    float: left;
    display: inline-block;
	cursor: pointer;
}

.child {
    height: 100%;
    width: 100%;
    cursor: zoom-in;
    background-size: cover;
    background-repeat: no-repeat;
    -webkit-transition: all .5s;
    -moz-transition: all .5s;
    -o-transition: all .5s;
    transition: all .5s;
}


.parent:hover .child, .parent:focus .child {
    -ms-transform: scale(1.2);
    -moz-transform: scale(1.2);
    -webkit-transform: scale(1.2);
    -o-transform: scale(1.2);
    transform: scale(1.2);
}

.parent:hover .child:before, .parent:focus .child:before {
    display: block;
}

.parent:hover a, .parent:focus a {
    display: block;
}

.child:before {
    content: "";
    display: none;
    height: 100%;
    width: 100%;
    position: absolute;
    top: 0;
    left: 0;
  
}
.product-discountedPrice, .product-price {
    font-size:24px!important;
}
.product-discountPercentage,.product-strike
{
    font-size:20px!important;
}
.pdp-selling-price {
    font-size: 16px;
    margin: 0 0 10px;
}
.pdp-selling-price {
    position: relative;
}
.pdp-vatInfo {
    color: #03a685;
    font-weight: 500;
    font-size: 14px;
    display: block;
    margin: 5px 10px 0 0;
    font-weight: 500;
}
.size-buttons-select-size {
    display: inline-block;
    font-size: 16px;
    margin: 0;
    color: black;
    font-weight: 500;
}
.size-buttons-size-header {
    margin: 0 0 10px;
    position: relative;
    line-height: 1;
}
.sizebtn,.sizebtn:hover
{
    border: 1px solid #ff3f6c;
    background-color: #fff;
    color: #ff3f6c!important;
    border-radius:40px;
    margin-bottom:10px;
}
.cartbtn
{
    background-color: #ff527b;
    margin: 10px;
    min-width: 108px;
    text-align: center;
    border-radius: 4px;
    font-size: 18px;
    font-weight: 500;
    padding: 10px 0px;
    min-width: 280px;
    color:#fff;
}
.wishbtn
{
    background-color: #fff;
    border-radius: 4px;
    color:#000;
    font-weight: 500;
    min-width: 108px;
    text-align: center;
    font-size: 18px;
    padding: 10px 0px;
    min-width: 250px;
    border: 1px solid #d4d5d9;
}
.cartbtn:hover
{
    color:#fff;
}
.wishbtn:hover
{
    border: 1px solid #535766; 
}
.SelectedSizeSellerInfo-sellerName
{
    margin-top: 6px;
    color: #282c3f;
    font-size: 16px;
    margin-bottom: 6px;
}
.pincode-deliveryContainer {
    margin-top: 30px;
}
.pincode-deliveryContainer>h4 {
    color: #282c3f;
    font-size: 16px;
    margin: 0;
    font-weight: 500;
    text-transform: uppercase;
    margin-bottom: 15px;
}
.pincode-code {
    border-radius: 5px;
    border: 1px solid #d4d5d9;
    -webkit-box-shadow: 0;
    box-shadow: 0;
    padding: 10px;
    font-size: 16px;
    min-width: 160px;
    outline: 0;
    width: 250px;
}
.pincode-check {
    position: relative;
    left: -60px;
    background-color: transparent;
}
.pincode-button {
    outline: 0;
    margin-top: 10px;
    font-size: 14px;
    font-weight: 500;
    background-color: #fff;
    border: 0;
    color: #ff3e6c;
    text-transform: capitalize;
}
.pincode-enterPincode {
    font-size: 13px;
    color: #282c3f;
    margin: 8px 0 0;
}

.meta-info {
    color: #282c3f;
    font-size: 16px;
    margin: 0;
    padding: 8px 0px 8px 0px;
    position: relative;
}
.meta-info .meta-desc {
    margin: 5px 0;
    display: inline-block;
    width: 90%;
    vertical-align: top;
}
.pdp-product-description-title {
    color: #282c3f;
    font-size: 16px;
    margin: 0;
    font-weight: 500;
    text-transform: uppercase;
}
.pdp-product-description-content {
    line-height: 1.4;
    font-size: 16px;
    margin-top: 12px;
    width: 84%;
}
.pdp-sizeFitDesc {
    font-weight: 400;
    border: none;
    margin-top: 12px;
}
.pdp-sizeFitDescTitle {
    text-transform: capitalize;
    font-weight: 500;
    font-size: 16px;
    border: none;
    padding-bottom: 5px;
}
.pdp-product-description-title {
    color: #282c3f;
    font-size: 16px;
    margin: 0;
    font-weight: 500;
    text-transform: uppercase;
}
.pdp-sizeFitDescContent {
    margin: 0;
    width: 90%;
}
.index-sizeFitDesc {
    font-weight: 400;
    border: none;
    margin-top: 12px;
}
.index-sizeFitDescTitle {
    text-transform: capitalize;
    font-weight: 500;
    font-size: 16px;
    border: none;
    padding-bottom: 5px;
}
.index-product-description-title {
    color: #282c3f;
    font-size: 16px;
    margin: 0;
    font-weight: 500;
    padding-bottom: 8px;
   
    text-transform: uppercase;
}
.index-tableContainer {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: start;
    -ms-flex-pack: start;
    justify-content: flex-start;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row;
}
.index-tableContainer .index-row:nth-child(odd) {
    margin-right: 10%;
}
.index-tableContainer .index-row {
    position: relative;
    border-bottom: 1px solid #eaeaec;
    margin: 0 0 12px;
    padding-bottom: 10px;
    -ms-flex-preferred-size: 40%;
    flex-basis: 40%;
}
.index-tableContainer .index-row .index-rowKey {
    position: relative;
    color: #7e818c;
    font-size: 12px;
    line-height: 1;
    margin-bottom: 5px;
}
.index-tableContainer .index-row .index-rowValue {
    position: relative;
    color: #282c3f;
    font-size: 16px;
    line-height: 1.2;
}
.index-showMoreText {
    font-size: 14px;
    font-weight: 500;
    color: #ff3f6c;
    margin-top: 4px;
    cursor: pointer;
}
.supplier-desktopCodeSupplier {
    margin-top: 15px;
}
.supplier-supplier {
    color: #282c3f;
    font-size: 16px;
    padding: 4px 0;
    margin-bottom: 6px;
}
.supplier-productSellerName, .supplier-styleId {
    color: #282c3f;
    font-weight: 500;
    position: relative;
    -webkit-tap-highlight-color: rgba(0,0,0,0);
}
.supplier-partner-name {
    color: #282c3f;
}
.supplier-desktopCodeSupplier .supplier-productSellerName {
    display: inline-block;
}
.supplier-viewmore-link {
    color: #282c3f;
    font-size: 14px;
    padding: 4px 0;
    margin-bottom: 6px;
    font-weight: 500;
    cursor: pointer;
}
.pdp-name {
    color: #535665;
    padding: 5px 20px 14px 0;
    font-size: 20px;
    opacity: .8;
    font-weight: 400;
    text-align: justify;
}
.index-crossLinkContainer {
    display: inline-block;
    margin: 35px 0 50px;
    width: 100%;
    text-align: center;
}
.index-links {
    display: inline-block;
    color: #ff3e6c;
    font-size: 14px;
    font-weight: 500;
    margin-right: 16px;
    text-transform: uppercase;
    text-decoration: none!important;
    background-color: transparent;
}
.index-links>div {
    border-radius: 24px;
    background-color: #fff;
    border: 1px solid #bfc0c6;
    padding: 16px 20px;
}
.index-arrow {
    display: inline-block;
    width: 6px;
    height: 6px;
    margin-left: 10px;
    border: solid #ff3e6c;
    border-width: 2px 2px 0 0;
    -webkit-transform: rotate(45deg);
    transform: rotate(45deg);
    margin-bottom: 1px;
}
.index-links>div:hover {
    color: #ff3e6c;
    border: 1px solid #ff3e6c;
    text-decoration: none!important;
}
/* Media Queries */
@media screen and (max-width: 960px) {
    .image-grid-container {
        width: 100%;
        padding:30px;
    }
    .pdp-description-container {
        width: 100%;
        padding:10%;
    }
}
@media screen and (max-width: 960px) {
    .parent {width: 100%; margin: 20px 0px}
		.wrapper {padding: 20px 20px;}
}
@media (min-width: 980px)
{
    .image-grid-container {
    float: left;
    width: 58%;
    padding-left: 60px;
}
.pdp-description-container {
    min-height: 820px;
    width: 42%;
    float: left;
    padding: 0 0 0 30px;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
}

}
</style>
</head>
<body>
<div class="container-fluid no-padding" >
<?php include("./header.php"); ?>

<section class="product spad">
<div class="text-banner-container"><h1 class="text-banner-title titleimg">Product Details</h1></div>
    <div class="container-fluid">
        <div class="row">
        <div class="image-grid-container">
        
                <div class="wrapper">
	<div class="parent" onclick="">
		<div class="child">
        <img 
                                src="./images/image2.jpeg" alt="">
		</div>
	</div>

	<div class="parent " onclick="">
		<div class="child bg-two">
        <img 
                                src="./images/image2.jpeg" alt="">
		</div>
	</div>
</div>


                <div class="wrapper">
	<div class="parent" onclick="">
		<div class="child bg-three">
        <img 
                                src="./images/image2.jpeg" alt="">	
		</div>
	</div>

	<div class="parent " onclick="">
		<div class="child bg-four">
        <img 
                                src="./images/image2.jpeg" alt="">
		</div>


            
                </div>
                </div>
                </div>
                <div class="pdp-description-container">
                    <div class="product__details__text">
                        <h3><?php if(isset( $_GET['name'])){echo $_GET['name'];} ?></h3>
                        <h1 class="pdp-name">Gold is a range of premium blankets</h1>
                        <div class="product__details__price"></div>
                        <div class="product-price"><span><span class="product-discountedPrice"><strong><?php if(isset( $_GET['prize'])){echo $_GET['prize'];} ?></strong></span><span class="product-strike"><?php if(isset( $_GET['cprize'])){echo $_GET['cprize'];} ?></span></span><span class="product-discountPercentage">(5% OFF)</span></div>
                        <p class="pdp-selling-price"><span class="pdp-vatInfo">inclusive of all taxes</span></p>
                        
                        <div class="size-buttons-size-header">
                        <h4 class="size-buttons-select-size">SELECT SIZE </h4>
                        </div>
                        <button class="btn  btn-outline sizebtn">King Size</button><br>
                        <div class="size-buttons-size-header">
                        <h4 class="size-buttons-select-size">Quantity  </h4>
                        </div>
                        <div class="product__details__quantity">
                            <div class="quantity-input-group">
                            <div class="input-group">
          <span class="input-group-btn">
              <button type="button" class="btn btn-default btn-number" style="font-size:20px;" disabled="disabled" data-type="minus" data-field="quant[1]">
                  <span class="glyphicon glyphicon-minus"></span>
              </button>
          </span>
          <input type="text" name="quant[1]" class="form-control input-number" value="1" min="1" max="10">
          <span class="input-group-btn">
              <button type="button" class="btn btn-default btn-number" style="font-size:20px;" data-type="plus" data-field="quant[1]">
                  <span class="glyphicon glyphicon-plus"></span>
              </button>
          </span>
      </div>
                            </div>
                           
                        </div><br>
                        
                        <div class="btn-group">
						<button type="button" class="btn cartbtn">
                        <i class="fa fa-shopping-bag" style="padding:5px;">
                               
                               </i> ADD TO BAG 
						</button>
					</div>
					<div class="btn-group">
						<button type="button" class="btn wishbtn">
                        <span class="glyphicon glyphicon-bookmark" style="padding:5px;"></span>
                        WISHLIST 
						</button>
					</div>
                    <hr class="line">
                    <div class="product-price" ><span><span class="product-discountedPrice" style="font-size:18px!important"><strong><?php if(isset( $_GET['prize'])){echo $_GET['prize'];} ?></strong></span><span class="product-strike" style="font-size:18px!important"><?php if(isset( $_GET['prize'])){echo $_GET['prize'];} ?></span></span><span class="product-discountPercentage" style="font-size:18px!important">(5% OFF)</span></div>
                    <div class="SelectedSizeSellerInfo-sellerName">Seller: <b>Mora Spain</b></div>
                    <hr class="line">
                    <div class="pincode-deliveryContainer"><h4>Delivery Options <i class="fa fa-truck"></i></h4><form autocomplete="off"><input type="text" placeholder="Enter pincode" class="pincode-code" value="" name="pincode"><input type="submit" class="pincode-check pincode-button" value="Check"></form><p class="pincode-enterPincode">Please enter PIN code to check delivery time &amp; Pay on Delivery Availability</p></div>
                    <div class="meta-container"><div class="meta-info"><div class="meta-desc">100% Original Products</div></div><div class="meta-info"><div class="meta-desc">Free Delivery on order above Rs. 799</div></div><div class="meta-info"><div class="meta-desc">Pay on delivery might be available</div></div><div class="meta-info"><div class="meta-desc">Easy 30 days returns and exchanges</div></div></div>
                      <div> 
                    <h4 class="pdp-product-description-title">Product Details <i class="fa fa-list-alt" aria-hidden="true"></i></h4>
                    <p class="pdp-product-description-content">Gold is a range of premium blankets</p> 
                    </div> 
                    <div class="pdp-sizeFitDesc"><h4 class="pdp-sizeFitDescTitle pdp-product-description-title">Size</h4><p class="pdp-sizeFitDescContent pdp-product-description-content">240 × 270 cm</p></div>
                     
                    <div class="pdp-sizeFitDesc"><h4 class="pdp-sizeFitDescTitle pdp-product-description-title">Material &amp; Care</h4><p class="pdp-sizeFitDescContent pdp-product-description-content">Material: 100% cotton<br>Machine Wash</p></div>
                    <div class="index-sizeFitDesc"><h4 class="index-sizeFitDescTitle index-product-description-title" style="padding-bottom: 12px;">Specifications</h4><div class="index-tableContainer"><div class="index-row"><div class="index-rowKey">Fabric</div><div class="index-rowValue">Cotton</div></div><div class="index-row"><div class="index-rowKey">Size</div><div class="index-rowValue">King Size</div></div><div class="index-row"><div class="index-rowKey">Length</div><div class="index-rowValue">Regular</div></div><div class="index-row"><div class="index-rowKey">Main Trend</div><div class="index-rowValue">New Basics</div></div><div class="index-row"><div class="index-rowKey">Multipack Set</div><div class="index-rowValue">Single</div></div><div class="index-row"><div class="index-rowKey">Color</div><div class="index-rowValue">Red</div></div><div class="index-row"><div class="index-rowKey">Occasion</div><div class="index-rowValue">Casual</div></div><div class="index-row"><div class="index-rowKey">Pattern</div><div class="index-rowValue">Solid</div></div></div><div class="index-showMoreText">See More</div></div>
                    <hr class="line">
                    <div class="undefined supplier-desktopCodeSupplier"><div class="supplier-supplier"><span>Product Code: <span class="supplier-styleId">11077774</span></span></div><div class="supplier-supplier"><span>Sold by: <span class="supplier-productSellerName">Mora Spain</span><span class="supplier-partner-name"></span></span></div><div class="supplier-viewmore-link"> View Supplier Information</div></div>
                   
                    </div>
                    
                </div>
                <div class="index-crossLinkContainer"><a class="index-links" href=""><div>More Blankets by Difference of Opinion<span class="index-arrow"></span></div></a><a class="index-links" href="#"><div>More Red Color Blankets<span class="index-arrow"></span></div></a><a class="index-links undefined" href="#"><div>More Blankets<span class="index-arrow"></span></div></a></div>
            </div>
    </div>
</section>
    <!-- Product Section End -->

    </div>
<?php include("./footer.php"); ?>
</div>
</body>
</html>