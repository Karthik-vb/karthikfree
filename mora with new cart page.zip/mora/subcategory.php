<htmL>
<head>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<link rel="stylesheet" href="mega-menu.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script src="mega-menu.js"></script>
</head>
<body>
<div class="container-fluid no-padding">
<?php include("./header.php"); ?>
<div class="container" style="margin-top:160px;">
    <div class="row">
        <div class="col">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="./index.php">Home</a></li>
                    <li class="breadcrumb-item"><a href="./subcategory.php?category=1">Category</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Sub-category</li>
                </ol>
            </nav>
        </div>
	</div>
	<?php if($_GET['category']==1){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<a href='./category.php?category=ACRYLIC'><span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/2Ply1.jpg" alt="...">
      			<h4>ACRYLIC</h4>
      			<!-- <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p> -->
      			
    		</span></a>
  		</div>
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
          <a href='./category.php?category=DOUBLEBLANKET'><span class="thumbnail">
      			<img  class="img-responsive box-img1" src="./images/3D-ART.jpg" alt="...">
      			<h4>DOUBLE BLANKET</h4>
      			<!-- <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p> -->
      		
    		</span></a>
  		</div>
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
          <a href='./category.php?category=Set4Piece'><span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/MGold_1.jpg" alt="...">
      			<h4>Set 4 Piece</h4>
      			<!-- <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p> -->
      		
    		</span></a>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
        <a href='./category.php?category=SingleBLANKET'><span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/MGold_Digital_2.jpg" alt="...">
      			<h4> Single Blanket</h4>
      			<!-- <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p> -->
      		
    		</span></a>
        </div>
       
        
  	
		 </div>
         <div class="row">
	
    <!-- BEGIN PRODUCTS -->
      <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
      <a href='./category.php?category=FURSCollection'> <span class="thumbnail">
              <img class="img-responsive box-img1" src="./images/image1.jpeg" alt="...">
              <h4>FURS Collection </h4>
              <!-- <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p> -->
              
        </span></a>
      </div>
      <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
      <a href='./category.php?category=Elegance'>  <span class="thumbnail">
              <img  class="img-responsive box-img1" src="./images/image2.jpeg" alt="...">
              <h4>Elegance</h4>
              <!-- <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p> -->
          
        </span></a>
      </div>
      </div>
   
<?php } ?>
<?php if($_GET['category']==2){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
          <a href='./category.php?category=SummerQuilts'>	<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/blanket.jpeg" alt="...">
      			<h4>Summer Quilts</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			
    		</span>
  		</div>
  	
		 </div></a>
<?php } ?>
        
<?php if($_GET['category']==3){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
          <a href='./category.php?category=SingleBedSheets'>	<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/image15.jpeg" alt="...">
      			<h4>Single Bed Sheets</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			
                  
    		</span></a>
  		</div>
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
          <a href='./category.php?category=DoubleBedSheets'><span class="thumbnail">
      			<img  class="img-responsive box-img1" src="./images/image16.jpeg" alt="...">
      			<h4>Double Bed Sheets</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			
                  
    		</span></a>
  		</div>
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
          <a href='./category.php?category=KingBedSheets'>	<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/image17.jpeg" alt="...">
      			<h4>King Bed Sheets</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      		
              
    		</span></a>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
        <a href='./category.php?category=FittedBedSheets'>	<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/image18.jpeg" alt="...">
      			<h4>Fitted Bed Sheets</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      		
              
    		</span></a>
        </div>
       
        
  	
		 </div>
<?php } ?>    
<?php if($_GET['category']==4){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		  <a href='./category.php?category=BabyPillow'>	<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/pillow1.jpeg" alt="...">
      			<h4>Baby Pillow</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			
    		</span></a>
  		</div>
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		  <a href='./category.php?category=LuxuryPillow'>	<span class="thumbnail">
      			<img  class="img-responsive box-img1" src="./images/pillow2.jpeg" alt="...">
      			<h4>Luxury Pillow</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      		
    		</span></a>
  		</div>
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		  <a href='./category.php?category=MedicatedPillow'>	<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/pillow3.jpeg" alt="...">
      			<h4>Medicated Pillow</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			
    		</span></a>
        </div>
      
		 </div>
<?php } ?>  
<?php if($_GET['category']==5){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    	  <a href='./category.php?category=OrientalCarpets'>	<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/carpet4.jpeg" alt="...">
      			<h4>Oriental Carpets</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			
    		</span></a>
  		</div>
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    	  <a href='./category.php?category=PlushCarpets'>	<span class="thumbnail">
      			<img  class="img-responsive box-img1" src="./images/carpet1.jpeg" alt="...">
      			<h4>Plush Carpets</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			
    		</span></a>
  		</div>
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    	  <a href='./category.php?category=ShagCarpets'>	<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/carpet2.jpeg" alt="...">
      			<h4>Shag Carpets</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			
    		</span></a>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
		<a href='./category.php?category=CutPileCarpets'>	<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/carpet3.jpeg" alt="...">
      			<h4>Cut Pile Carpets</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			
    		</span></a>
        </div>
       
        
  	
		 </div>
         <div class="row">
	
    <!-- BEGIN PRODUCTS -->
      <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
	  <a href='./category.php?category=LoopPileCarpets'>  <span class="thumbnail">
              <img class="img-responsive box-img1" src="./images/carpet4.jpeg" alt="...">
              <h4>Loop Pile Carpets</h4>
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
              
        </span></a>
      </div>
      <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
	  <a href='./category.php?category=CutLoopCarpets'>  <span class="thumbnail">
              <img  class="img-responsive box-img1" src="./images/carpet1.jpeg" alt="...">
              <h4>Cut & Loop Carpets</h4>
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
              
        </span></a>
      </div>
      <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
	  <a href='./category.php?category=FlatweaveCarpets'>  <span class="thumbnail">
              <img class="img-responsive box-img1" src="./images/carpet2.jpeg" alt="...">
              <h4>Flatweave Carpets</h4>
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
              
        </span></a>
    </div>
   
     </div>
<?php } ?>  
</div>

<?php include("./footer.php"); ?>
</div>
</body>
</html>