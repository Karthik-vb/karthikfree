<htmL>
<head>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<link rel="stylesheet" href="mega-menu.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script src="mega-menu.js"></script>
<style>

p {
    font-size: 16px;
    font-family: "Cairo", sans-serif;
    color: #837e7e;
    font-weight: 400;
    line-height: 26px;
    margin: 0 0 15px 0;
}
.spad
{
    margin-top:100px;
}
</style>
</head>
<body>
<div class="container-fluid no-padding" >
<?php include("./header.php"); ?>
<!-- Breadcrumb Section Begin -->
<!-- <section class="breadcrumb-section set-bg" style="background: #000000;">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="breadcrumb__text">
                    <h2>Product Details</h2>
                </div>
            </div>
        </div>
    </div>
</section> -->
<!-- Breadcrumb Section End -->
<section class="product spad">
<div class="text-banner-container"><h1 class="text-banner-title titleimg">Product Details</h1></div>
    <div class="container">
        <div class="row">
                <div class="col-lg-6 col-md-6">
                    <div class="product__details__pic">
                        <div class="product__details__pic__item">
                            <img class="product__details__pic__item--large"
                                src="./images/image2.jpeg" alt="">
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="product__details__text">
                        <h3><?php if(isset( $_GET['name'])){echo $_GET['name'];} ?></h3>
                        <div class="product__details__price"><?php if(isset( $_GET['prize'])){echo $_GET['prize'];} ?></div>
                        <p>Gold Digital is a range of prime quality blankets that are available in a light beige coloured flower print. Manufactured with a balanced combination of acrylic and polyester; these blankets are crafted to cater to your comforts and luxuries.</p>
                        <div class="product__details__quantity">
                            <div class="quantity-input-group">
                            <div class="input-group">
          <span class="input-group-btn">
              <button type="button" class="btn btn-default btn-number" style="font-size:20px;" disabled="disabled" data-type="minus" data-field="quant[1]">
                  <span class="glyphicon glyphicon-minus"></span>
              </button>
          </span>
          <input type="text" name="quant[1]" class="form-control input-number" value="1" min="1" max="10">
          <span class="input-group-btn">
              <button type="button" class="btn btn-default btn-number" style="font-size:20px;" data-type="plus" data-field="quant[1]">
                  <span class="glyphicon glyphicon-plus"></span>
              </button>
          </span>
      </div>
                            </div>
                           
                        </div>
                        <a href="#" class="btn btn-success cartbtn">ADD TO CART</a>
                        <ul>
                            <li><b>Brand name</b> <span>MORA SPAIN</span></li>
                            <li><b>Product name</b> <span><?php if(isset( $_GET['name'])){echo $_GET['name'];} ?></span></li>
                            <li><b>Prize</b> <span><?php if(isset( $_GET['prize'])){echo $_GET['prize'];} ?></span></li>
                            <li><b>Size</b> <span> KING SIZE </span></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="product__details__tab">
                       <ul class="nav nav-tabs" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" data-toggle="tab" href="#tabs-1" role="tab"
                                    aria-selected="true">Description</a>
                            </li>
                        </ul>
                        <div class="tab-content">
                            <div class="tab-pane active" id="tabs-1" role="tabpanel">
                                <div class="product__details__tab__desc">
                                    <p>Gold Digital is a range of prime quality blankets that are available in a light beige coloured flower print. Manufactured with a balanced combination of acrylic and polyester; these blankets are crafted to cater to your comforts and luxuries.</p>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
    </div>
</section>
    <!-- Product Section End -->

    </div>
<?php include("./footer.php"); ?>
</div>
</body>
</html>