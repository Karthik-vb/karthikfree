

              
<nav class="navbar navbar-icon-top navbar-default navbar-fixed-top">
<div class="container-fluid">
        <!--brand, search-->
        <div class="row">
        <div class="navbar-header">
         <button type="button" class="navbar-toggle nav-btns" data-toggle="collapse" data-target="#main-navbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
            <a  href="./index.php"><img src="./logo1.png" class="logo-header"></a>
           
         </div>
<!-- <ul class="nav navbar-nav navbar-right mobilehide">
            <li>
             <form class="navbar-form navbar-search" role="search">
                <div class="input-group search-form">
                
                    <div class="input-group-btn">
                        <button type="button" class="btn btn-search btn-default dropdown-toggle" data-toggle="dropdown">
                            <span class="glyphicon glyphicon-search"></span>
                            <span class="label-icon">ALL</span>
                            <span class="caret"></span>
                        </button>
                        <ul class="dropdown-menu searchdrop" role="menu">
                           <li class="slist">
                                <a href="#">
                                    <span class="label-icon">Blanket  - بطانيات</span>
                                </a>
                            </li>
                            <li class="slist">
                                <a href="#">
                             
                                <span class="label-icon">Quilt - لحاف</span>
                                </a>
                            </li>
                            <li class="slist">
                                <a href="#">
                                <span class="label-icon">Pillows - مخدات</span>
                                </a>
                            </li>
                        </ul>
                    </div>
        
                    <input type="text" class="form-control search-input">
                
                    <div class="input-group-btn">
                        <button type="button" class="btn btn-search btn-default">
                        GO
                        </button>
                         
                         
                    </div>
                </div>  
            </form>   
              </li>
            <li class="dropdown mega-dropdown">
                  <a href="#" class="dropdown-toggle" style="border-bottom-color:#0db7af;" data-toggle="dropdown" role="button" aria-expanded="false">Account & Lists</a>

                  <ul class="dropdown-menu mega-dropdown-menu row accountlist">
                     
                     <li class="col-sm-6">
                        <ul>
                           <li class="dropdown-header green">Your List</li>
                           <li class='green1'><a href="#">Wishlist</a></li>
                           <li class='green1'><a href="#">Payment History</a></li>
                           <li class='green1'><a href="#">Your Dabbous Membership </a></li>
                           <li class='green1'><a href="#">Your Dabbous bussiness card</a></li>
                           <li class='green1'><a href="#">Your Dabbous Rewards Points</a></li>
                        </ul>
                     </li>
                     <li class="col-sm-6">
                        <ul>
                           <li class="dropdown-header green">Your Account</li>
                            <li class='green1'><a href="#">Account</a></li>
                           <li class='green1'><a href="#">Your Order</a></li>
                           <li class='green1'><a href="#">Saved cards </a></li>
                           <li class='green1'><a href="#">Delivery Address</a></li>
                           <li class='green1'><a href="#">Sign out</a></li>

                        </ul>
                     </li>
                  </ul>

               </li>
                    <li >
                        <a href="./cart.php" class="shop-btn" style="border:none;">
                        <i class="fa fa-shopping-cart icon-cart">
                                <span class="badge badge-danger">11</span>
                            </i><br>
                            AddToCart
                        </a>
                    </li>
               </ul> -->
<!-- </div>
        
<div class="row">  -->

         <div class="collapse navbar-collapse" id="main-navbar">
            <ul class="nav navbar-nav head-nav">
            <li class="dropdown mega-dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" style="border-bottom-color:#ee5f73;" role="button" aria-expanded="false">MEN</a>

                  <ul class="dropdown-menu mega-dropdown-menu row">
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header red">New in Stores</li>
                           <li class='red1'><a href="#">Default Navbar</a></li>
                           <li class='red1'><a href="#">Lovely Fonts</a></li>
                           <li class='red1'><a href="#">Responsive Dropdown </a></li>
                           <li class='red1'><a href="#">Default Navbar</a></li>
                           <li class='red1'><a href="#">Lovely Fonts</a></li>
                           <li class='red1'><a href="#">Responsive Dropdown </a></li>
                           <li class="dropdown-header red">Tops</li>
                           <li class='red1'><a href="#">Good Typography</a></li>
                        </ul>
                     </li>
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header red">Dresses</li>
                            <li class='red1'><a href="#">Default Navbar</a></li>
                           <li class='red1'><a href="#">Lovely Fonts</a></li>
                           <li class='red1'><a href="#">Responsive Dropdown </a></li>
                           <li class='red1'><a href="#">Default Navbar</a></li>
                           <li class='red1'><a href="#">Lovely Fonts</a></li>
                           <li class='red1'><a href="#">Responsive Dropdown </a></li>
                           <li class="dropdown-header red">Tops</li>
                           <li class='red1'><a href="#">Good Typography</a></li>
                        </ul>
                     </li>
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header red">Jackets</li>
                           <li class='red1'><a href="#">Easy to customize</a></li>
                           <li class='red1'><a href="#">Glyphicons</a></li>
                           <li class='red1'><a href="#">Pull Right Elements</a></li>
                           
                           <li class="dropdown-header red">Pants</li>
                           <li class='red1'><a href="#">Coloured Headers</a></li>
                           <li class='red1'><a href="#">Primary Buttons & Default</a></li>
                           <li class='red1'><a href="#">Calls to action</a></li>
                        </ul>
                     </li>
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header red">Jackets</li>
                           <li class='red1'><a href="#">Easy to customize</a></li>
                           <li class='red1'><a href="#">Glyphicons</a></li>
                           <li class='red1'><a href="#">Pull Right Elements</a></li>
                           <li class="dropdown-header red">Pants</li>
                           <li class='red1'><a href="#">Coloured Headers</a></li>
                           <li class='red1'><a href="#">Primary Buttons & Default</a></li>
                           <li class='red1'><a href="#">Calls to action</a></li>
                        </ul>
                     </li>
                  </ul>

               </li>
               <li class="dropdown mega-dropdown">
                  <a href="#" class="dropdown-toggle" style="border-bottom-color:#ee5f73;" data-toggle="dropdown" role="button" aria-expanded="false">WOMEN</a>

                  <ul class="dropdown-menu mega-dropdown-menu row">
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header red">New in Stores</li>
                           <li class='red1'><a href="#">Default Navbar</a></li>
                           <li class='red1'><a href="#">Lovely Fonts</a></li>
                           <li class='red1'><a href="#">Responsive Dropdown </a></li>
                           <li class='red1'><a href="#">Default Navbar</a></li>
                           <li class='red1'><a href="#">Lovely Fonts</a></li>
                           <li class='red1'><a href="#">Responsive Dropdown </a></li>
                           <li class="dropdown-header red">Tops</li>
                           <li class='red1'><a href="#">Good Typography</a></li>
                        </ul>
                     </li>
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header red">Dresses</li>
                            <li class='red1'><a href="#">Default Navbar</a></li>
                           <li class='red1'><a href="#">Lovely Fonts</a></li>
                           <li class='red1'><a href="#">Responsive Dropdown </a></li>
                           <li class='red1'><a href="#">Default Navbar</a></li>
                           <li class='red1'><a href="#">Lovely Fonts</a></li>
                           <li class='red1'><a href="#">Responsive Dropdown </a></li>
                           <li class="dropdown-header red">Tops</li>
                           <li class='red1'><a href="#">Good Typography</a></li>
                        </ul>
                     </li>
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header red">Jackets</li>
                           <li class='red1'><a href="#">Easy to customize</a></li>
                           <li class='red1'><a href="#">Glyphicons</a></li>
                           <li class='red1'><a href="#">Pull Right Elements</a></li>
                           
                           <li class="dropdown-header red">Pants</li>
                           <li class='red1'><a href="#">Coloured Headers</a></li>
                           <li class='red1'><a href="#">Primary Buttons & Default</a></li>
                           <li class='red1'><a href="#">Calls to action</a></li>
                        </ul>
                     </li>
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header red">Jackets</li>
                           <li class='red1'><a href="#">Easy to customize</a></li>
                           <li class='red1'><a href="#">Glyphicons</a></li>
                           <li class='red1'><a href="#">Pull Right Elements</a></li>
                           <li class="dropdown-header red">Pants</li>
                           <li class='red1'><a href="#">Coloured Headers</a></li>
                           <li class='red1'><a href="#">Primary Buttons & Default</a></li>
                           <li class='red1'><a href="#">Calls to action</a></li>
                        </ul>
                     </li>
                  </ul>

               </li>
               <li class="dropdown mega-dropdown">
                  <a href="#" class="dropdown-toggle" style="border-bottom-color:#ee5f73;" data-toggle="dropdown" role="button" aria-expanded="false">KIDS</a>

                  <ul class="dropdown-menu mega-dropdown-menu row">
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header red">New in Stores</li>
                           <li class='red1'><a href="#">Default Navbar</a></li>
                           <li class='red1'><a href="#">Lovely Fonts</a></li>
                           <li class='red1'><a href="#">Responsive Dropdown </a></li>
                           <li class='red1'><a href="#">Default Navbar</a></li>
                           <li class='red1'><a href="#">Lovely Fonts</a></li>
                           <li class='red1'><a href="#">Responsive Dropdown </a></li>
                           <li class="dropdown-header red">Tops</li>
                           <li class='red1'><a href="#">Good Typography</a></li>
                        </ul>
                     </li>
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header red">Dresses</li>
                            <li class='red1'><a href="#">Default Navbar</a></li>
                           <li class='red1'><a href="#">Lovely Fonts</a></li>
                           <li class='red1'><a href="#">Responsive Dropdown </a></li>
                           <li class='red1'><a href="#">Default Navbar</a></li>
                           <li class='red1'><a href="#">Lovely Fonts</a></li>
                           <li class='red1'><a href="#">Responsive Dropdown </a></li>
                           <li class="dropdown-header red">Tops</li>
                           <li class='red1'><a href="#">Good Typography</a></li>
                        </ul>
                     </li>
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header red">Jackets</li>
                           <li class='red1'><a href="#">Easy to customize</a></li>
                           <li class='red1'><a href="#">Glyphicons</a></li>
                           <li><a href="#">Pull Right Elements</a></li>
                           
                           <li class="dropdown-header red">Pants</li>
                           <li class='red1'><a href="#">Coloured Headers</a></li>
                           <li class='red1'><a href="#">Primary Buttons & Default</a></li>
                           <li class='red1'><a href="#">Calls to action</a></li>
                        </ul>
                     </li>
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header red">Jackets</li>
                           <li class='red1'><a href="#">Easy to customize</a></li>
                           <li class='red1'><a href="#">Glyphicons</a></li>
                           <li class='red1'><a href="#">Pull Right Elements</a></li>
                           <li class="dropdown-header red">Pants</li>
                           <li class='red1'><a href="#">Coloured Headers</a></li>
                           <li class='red1'><a href="#">Primary Buttons & Default</a></li>
                           <li class='red1'><a href="#">Calls to action</a></li>
                        </ul>
                     </li>
                  </ul>

               </li>
               <li class="dropdown mega-dropdown">
                  <a href="#" class="dropdown-toggle" style="border-bottom-color:#ee5f73;" data-toggle="dropdown" role="button" aria-expanded="false">HOME & LIVING</a>

                  <ul class="dropdown-menu mega-dropdown-menu row">
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header red">New in Stores</li>
                           <li class='red1'><a href="#">Default Navbar</a></li>
                           <li class='red1'><a href="#">Lovely Fonts</a></li>
                           <li class='red1'><a href="#">Responsive Dropdown </a></li>
                           <li class='red1'><a href="#">Default Navbar</a></li>
                           <li class='red1'><a href="#">Lovely Fonts</a></li>
                           <li class='red1'><a href="#">Responsive Dropdown </a></li>
                           <li class="dropdown-header red">Tops</li>
                           <li class='red1'><a href="#">Good Typography</a></li>
                        </ul>
                     </li>
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header red">Dresses</li>
                            <li class='red1'><a href="#">Default Navbar</a></li>
                           <li class='red1'><a href="#">Lovely Fonts</a></li>
                           <li class='red1'><a href="#">Responsive Dropdown </a></li>
                           <li class='red1'><a href="#">Default Navbar</a></li>
                           <li class='red1'><a href="#">Lovely Fonts</a></li>
                           <li class='red1'><a href="#">Responsive Dropdown </a></li>
                           <li class="dropdown-header red">Tops</li>
                           <li class='red1'><a href="#">Good Typography</a></li>
                        </ul>
                     </li>
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header red">Jackets</li>
                           <li class='red1'><a href="#">Easy to customize</a></li>
                           <li class='red1'><a href="#">Glyphicons</a></li>
                           <li class='red1'><a href="#">Pull Right Elements</a></li>
                           
                           <li class="dropdown-header red">Pants</li>
                           <li class='red1'><a href="#">Coloured Headers</a></li>
                           <li class='red1'><a href="#">Primary Buttons & Default</a></li>
                           <li class='red1'><a href="#">Calls to action</a></li>
                        </ul>
                     </li>
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header red">Jackets</li>
                           <li class='red1'><a href="#">Easy to customize</a></li>
                           <li class='red1'><a href="#">Glyphicons</a></li>
                           <li class='red1'><a href="#">Pull Right Elements</a></li>
                           <li class="dropdown-header red">Pants</li>
                           <li class='red1'><a href="#">Coloured Headers</a></li>
                           <li class='red1'><a href="#">Primary Buttons & Default</a></li>
                           <li class='red1'><a href="#">Calls to action</a></li>
                        </ul>
                     </li>
                  </ul>

               </li>
          
            </ul>
            
            
            <ul class="nav navbar-nav navbar-right">
            <li>
               <form class="form-inline search-form">
             
             <input class="form-control search-input rounded-0 border-dark border-right-0" type="search" placeholder="Search for products, brands and more" aria-label="Search">
             <button class="btn btn-light search-btn border-left-0 border-dark rounded-0" type="submit">
                <i class="fa fa-search text-secondary "></i>
             </button>
          </form>
              </li>
            <li class="dropdown mega-dropdown">
                
                  <a href="#" class="dropdown-toggle" style="border-bottom-color:#ee5f73;" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                            <i class="fa fa-user"></i>
                            Account & Lists 
                        </a>
                  <ul class="dropdown-menu mega-dropdown-menu row accountlist">
                     
                     <li class="col-sm-6">
                        <ul>
                           <li class="dropdown-header red">Your List</li>
                           <li class='red1'><a href="#">Wishlist</a></li>
                           <li class='red1'><a href="#">Payment History</a></li>
                           <li class='red1'><a href="#">Your Dabbous Membership </a></li>
                           <li class='red1'><a href="#">Your Dabbous bussiness card</a></li>
                           <li class='red1'><a href="#">Your Dabbous Rewards Points</a></li>
                        </ul>
                     </li>
                     <li class="col-sm-6">
                        <ul>
                           <li class="dropdown-header red">Your Account</li>
                            <li class='red1'><a href="#">Account</a></li>
                           <li class='red1'><a href="#">Your Order</a></li>
                           <li class='red1'><a href="#">Saved cards </a></li>
                           <li class='red1'><a href="#">Delivery Address</a></li>
                           <li class='red1'><a href="#">Sign out</a></li>

                        </ul>
                     </li>
                  </ul>

               </li>
                    <li >
                        <a href="#"  style="border:none;">
                        <i class="fa fa-shopping-cart">
                               
                            </i>
                            Order Track
                        </a>
                        
                    </li>
                    <li>
                    <a href="./cart.php"  style="border:none;">
                    <i class="fa fa-shopping-bag">
                                <span class="badge badge-danger">11</span>
                            </i>
                            AddToCart
                        </a>
                  </li>
               </ul>
          
         </div>
         <!-- /.nav-collapse -->
      </nav>
</div>
</div>