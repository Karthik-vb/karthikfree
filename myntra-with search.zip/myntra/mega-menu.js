jQuery(document).ready(function(){
   

    $(".dropdown").hover(
        function() { $('.dropdown-menu', this).fadeIn(300);
        },
        function() { $('.dropdown-menu', this).fadeOut(300);
    });
   

   
});
$(function(){
$(".input-group-btn .dropdown-menu .slist a").click(function(){

    var selText = $(this).html();

    //working version - for single button //
   //$('.btn:first-child').html(selText+'<span class="caret"></span>');  
   
   //working version - for multiple buttons //
   $(this).parents('.input-group-btn').find('.btn-search').html(selText);

});
});