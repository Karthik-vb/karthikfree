<htmL>
<head>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<link rel="stylesheet" href="mega-menu.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script src="mega-menu.js"></script>
</head>
<body>
<div class="container-fluid no-padding">
<?php include("./header.php"); ?>
<div class="container" style="margin-top:160px;">
    <div class="row">
        <div class="col">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="./index.php">Home</a></li>
                    <li class="breadcrumb-item"><a href="./category.php">Category</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Sub-category</li>
                </ol>
            </nav>
        </div>
	</div>
	<?php if($_GET['category']==1){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/image1.jpeg" alt="...">
      			<h4>Blanket  - بطانيات</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
                <div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
  		</div>
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img  class="img-responsive box-img1" src="./images/image2.jpeg" alt="...">
      			<h4>Blanket  - بطانيات</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
               <div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
  		</div>
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/image3.jpeg" alt="...">
      			<h4>Blanket  - بطانيات</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
      			<div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/image4.jpeg" alt="...">
      			<h4>Blanket  - بطانيات</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
      			<div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
        </div>
       
        
  	
		 </div>
<?php } ?>
<?php if($_GET['category']==2){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/blanket.jpeg" alt="...">
      			<h4>Quilt - لحاف</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
                <div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
  		</div>
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img  class="img-responsive box-img1" src="./images/blanket2.jpeg" alt="...">
      			<h4>Quilt - لحاف</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
               <div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
  		</div>
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/blanket3.jpeg" alt="...">
      			<h4>Quilt - لحاف</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
      			<div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/blanket5.jpeg" alt="...">
      			<h4>Quilt - لحاف</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
      			<div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
        </div>
       
        
  	
		 </div>
<?php } ?>
        
<?php if($_GET['category']==3){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/image15.jpeg" alt="...">
      			<h4>Bed Sheet - شرشف</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
                <div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
  		</div>
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img  class="img-responsive box-img1" src="./images/image16.jpeg" alt="...">
      			<h4>Bed Sheet - شرشف</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
               <div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
  		</div>
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/image17.jpeg" alt="...">
      			<h4>Bed Sheet - شرشف</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
      			<div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/image18.jpeg" alt="...">
      			<h4>Bed Sheet - شرشف</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
      			<div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
        </div>
       
        
  	
		 </div>
<?php } ?>    
<?php if($_GET['category']==4){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/pillow1.jpeg" alt="...">
      			<h4>Pillows - مخدات</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
                <div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
  		</div>
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img  class="img-responsive box-img1" src="./images/pillow2.jpeg" alt="...">
      			<h4>Pillows - مخدات</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
               <div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
  		</div>
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/pillow3.jpeg" alt="...">
      			<h4>Pillows - مخدات</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
      			<div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/pillow4.jpeg" alt="...">
      			<h4>Pillows - مخدات</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
      			<div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
        </div>
       
        
  	
		 </div>
<?php } ?>  
<?php if($_GET['category']==5){ ?>
    <div class="row">
	
    	<!-- BEGIN PRODUCTS -->
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/carpet4.jpeg" alt="...">
      			<h4>Carpets - سجاد</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
                <div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
  		</div>
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img  class="img-responsive box-img1" src="./images/carpet1.jpeg" alt="...">
      			<h4>Carpets - سجاد</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
               <div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
  		</div>
  		<div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/carpet2.jpeg" alt="...">
      			<h4>Carpets - سجاد</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
      			<div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-6 portfolio-item1">
    		<span class="thumbnail">
      			<img class="img-responsive box-img1" src="./images/carpet3.jpeg" alt="...">
      			<h4>Carpets - سجاد</h4>
      			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
      			<hr class="line">
      			<div class="row">
      				<div class="col-md-6 col-sm-6">
                  <div class="product-price"><span><span class="product-discountedPrice">Rs.799</span><span class="product-strike">Rs.1999</span></span><span class="product-discountPercentage">(60% OFF)</span></div>
      				</div>
      				<div class="col-md-6 col-sm-6">
      				 <a href="http://cookingfoodsworld.blogspot.in/" target="_blank" >	<button class="btn btn-info right" > BUY ITEM</button></a>
      				
                </div>
      			</div>
    		</span>
        </div>
       
        
  	
		 </div>
<?php } ?>  
</div>

<?php include("./footer.php"); ?>
</div>
</body>
</html>