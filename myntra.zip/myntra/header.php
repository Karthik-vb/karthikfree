<nav class="navbar navbar-default navbar-fixed-top">
         <div class="navbar-header">
         <button type="button" class="navbar-toggle nav-btns" data-toggle="collapse" data-target="#main-navbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
            <a  href="./index.php"><img src="./logo.png" class="logo-header"></a>
           
         </div>
         

         <div class="collapse navbar-collapse" id="main-navbar">
            <ul class="nav navbar-nav head-nav">
            <li class="dropdown mega-dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" style="border-bottom-color:#ee5f73;" role="button" aria-expanded="false">MEN</a>

                  <ul class="dropdown-menu mega-dropdown-menu row">
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header red">New in Stores</li>
                           <li><a href="#">Default Navbar</a></li>
                           <li><a href="#">Lovely Fonts</a></li>
                           <li><a href="#">Responsive Dropdown </a></li>
                           <li><a href="#">Default Navbar</a></li>
                           <li><a href="#">Lovely Fonts</a></li>
                           <li><a href="#">Responsive Dropdown </a></li>
                           <li class="dropdown-header red">Tops</li>
                           <li><a href="#">Good Typography</a></li>
                        </ul>
                     </li>
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header red">Dresses</li>
                            <li><a href="#">Default Navbar</a></li>
                           <li><a href="#">Lovely Fonts</a></li>
                           <li><a href="#">Responsive Dropdown </a></li>
                           <li><a href="#">Default Navbar</a></li>
                           <li><a href="#">Lovely Fonts</a></li>
                           <li><a href="#">Responsive Dropdown </a></li>
                           <li class="dropdown-header red">Tops</li>
                           <li><a href="#">Good Typography</a></li>
                        </ul>
                     </li>
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header red">Jackets</li>
                           <li><a href="#">Easy to customize</a></li>
                           <li><a href="#">Glyphicons</a></li>
                           <li><a href="#">Pull Right Elements</a></li>
                           
                           <li class="dropdown-header red">Pants</li>
                           <li><a href="#">Coloured Headers</a></li>
                           <li><a href="#">Primary Buttons & Default</a></li>
                           <li><a href="#">Calls to action</a></li>
                        </ul>
                     </li>
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header red">Jackets</li>
                           <li><a href="#">Easy to customize</a></li>
                           <li><a href="#">Glyphicons</a></li>
                           <li><a href="#">Pull Right Elements</a></li>
                           <li class="dropdown-header red">Pants</li>
                           <li><a href="#">Coloured Headers</a></li>
                           <li><a href="#">Primary Buttons & Default</a></li>
                           <li><a href="#">Calls to action</a></li>
                        </ul>
                     </li>
                  </ul>

               </li>
               <li class="dropdown mega-dropdown">
                  <a href="#" class="dropdown-toggle" style="border-bottom-color:#fb56c1;" data-toggle="dropdown" role="button" aria-expanded="false">WOMEN</a>

                  <ul class="dropdown-menu mega-dropdown-menu row">
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header pink">New in Stores</li>
                           <li><a href="#">Default Navbar</a></li>
                           <li><a href="#">Lovely Fonts</a></li>
                           <li><a href="#">Responsive Dropdown </a></li>
                           <li><a href="#">Default Navbar</a></li>
                           <li><a href="#">Lovely Fonts</a></li>
                           <li><a href="#">Responsive Dropdown </a></li>
                           <li class="dropdown-header pink">Tops</li>
                           <li><a href="#">Good Typography</a></li>
                        </ul>
                     </li>
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header pink">Dresses</li>
                            <li><a href="#">Default Navbar</a></li>
                           <li><a href="#">Lovely Fonts</a></li>
                           <li><a href="#">Responsive Dropdown </a></li>
                           <li><a href="#">Default Navbar</a></li>
                           <li><a href="#">Lovely Fonts</a></li>
                           <li><a href="#">Responsive Dropdown </a></li>
                           <li class="dropdown-header pink">Tops</li>
                           <li><a href="#">Good Typography</a></li>
                        </ul>
                     </li>
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header pink">Jackets</li>
                           <li><a href="#">Easy to customize</a></li>
                           <li><a href="#">Glyphicons</a></li>
                           <li><a href="#">Pull Right Elements</a></li>
                           
                           <li class="dropdown-header pink">Pants</li>
                           <li><a href="#">Coloured Headers</a></li>
                           <li><a href="#">Primary Buttons & Default</a></li>
                           <li><a href="#">Calls to action</a></li>
                        </ul>
                     </li>
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header pink">Jackets</li>
                           <li><a href="#">Easy to customize</a></li>
                           <li><a href="#">Glyphicons</a></li>
                           <li><a href="#">Pull Right Elements</a></li>
                           <li class="dropdown-header pink">Pants</li>
                           <li><a href="#">Coloured Headers</a></li>
                           <li><a href="#">Primary Buttons & Default</a></li>
                           <li><a href="#">Calls to action</a></li>
                        </ul>
                     </li>
                  </ul>

               </li>
               <li class="dropdown mega-dropdown">
                  <a href="#" class="dropdown-toggle" style="border-bottom-color:#f26a10;" data-toggle="dropdown" role="button" aria-expanded="false">KIDS</a>

                  <ul class="dropdown-menu mega-dropdown-menu row">
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header orange">New in Stores</li>
                           <li><a href="#">Default Navbar</a></li>
                           <li><a href="#">Lovely Fonts</a></li>
                           <li><a href="#">Responsive Dropdown </a></li>
                           <li><a href="#">Default Navbar</a></li>
                           <li><a href="#">Lovely Fonts</a></li>
                           <li><a href="#">Responsive Dropdown </a></li>
                           <li class="dropdown-header orange">Tops</li>
                           <li><a href="#">Good Typography</a></li>
                        </ul>
                     </li>
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header orange">Dresses</li>
                            <li><a href="#">Default Navbar</a></li>
                           <li><a href="#">Lovely Fonts</a></li>
                           <li><a href="#">Responsive Dropdown </a></li>
                           <li><a href="#">Default Navbar</a></li>
                           <li><a href="#">Lovely Fonts</a></li>
                           <li><a href="#">Responsive Dropdown </a></li>
                           <li class="dropdown-header orange">Tops</li>
                           <li><a href="#">Good Typography</a></li>
                        </ul>
                     </li>
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header orange">Jackets</li>
                           <li><a href="#">Easy to customize</a></li>
                           <li><a href="#">Glyphicons</a></li>
                           <li><a href="#">Pull Right Elements</a></li>
                           
                           <li class="dropdown-header orange">Pants</li>
                           <li><a href="#">Coloured Headers</a></li>
                           <li><a href="#">Primary Buttons & Default</a></li>
                           <li><a href="#">Calls to action</a></li>
                        </ul>
                     </li>
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header orange">Jackets</li>
                           <li><a href="#">Easy to customize</a></li>
                           <li><a href="#">Glyphicons</a></li>
                           <li><a href="#">Pull Right Elements</a></li>
                           <li class="dropdown-header orange">Pants</li>
                           <li><a href="#">Coloured Headers</a></li>
                           <li><a href="#">Primary Buttons & Default</a></li>
                           <li><a href="#">Calls to action</a></li>
                        </ul>
                     </li>
                  </ul>

               </li>
               <li class="dropdown mega-dropdown">
                  <a href="#" class="dropdown-toggle" style="border-bottom-color:#f2c210;" data-toggle="dropdown" role="button" aria-expanded="false">HOME & LIVING</a>

                  <ul class="dropdown-menu mega-dropdown-menu row">
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header yellow">New in Stores</li>
                           <li><a href="#">Default Navbar</a></li>
                           <li><a href="#">Lovely Fonts</a></li>
                           <li><a href="#">Responsive Dropdown </a></li>
                           <li><a href="#">Default Navbar</a></li>
                           <li><a href="#">Lovely Fonts</a></li>
                           <li><a href="#">Responsive Dropdown </a></li>
                           <li class="dropdown-header yellow">Tops</li>
                           <li><a href="#">Good Typography</a></li>
                        </ul>
                     </li>
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header yellow">Dresses</li>
                            <li><a href="#">Default Navbar</a></li>
                           <li><a href="#">Lovely Fonts</a></li>
                           <li><a href="#">Responsive Dropdown </a></li>
                           <li><a href="#">Default Navbar</a></li>
                           <li><a href="#">Lovely Fonts</a></li>
                           <li><a href="#">Responsive Dropdown </a></li>
                           <li class="dropdown-header yellow">Tops</li>
                           <li><a href="#">Good Typography</a></li>
                        </ul>
                     </li>
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header yellow">Jackets</li>
                           <li><a href="#">Easy to customize</a></li>
                           <li><a href="#">Glyphicons</a></li>
                           <li><a href="#">Pull Right Elements</a></li>
                           
                           <li class="dropdown-header yellow">Pants</li>
                           <li><a href="#">Coloured Headers</a></li>
                           <li><a href="#">Primary Buttons & Default</a></li>
                           <li><a href="#">Calls to action</a></li>
                        </ul>
                     </li>
                     <li class="col-sm-3">
                        <ul>
                           <li class="dropdown-header yellow">Jackets</li>
                           <li><a href="#">Easy to customize</a></li>
                           <li><a href="#">Glyphicons</a></li>
                           <li><a href="#">Pull Right Elements</a></li>
                           <li class="dropdown-header yellow">Pants</li>
                           <li><a href="#">Coloured Headers</a></li>
                           <li><a href="#">Primary Buttons & Default</a></li>
                           <li><a href="#">Calls to action</a></li>
                        </ul>
                     </li>
                  </ul>

               </li>
            </ul>
            
            
            <ul class="nav navbar-nav navbar-right">
                    <li >
                        <a href="./cart.php" class="shop-btn" style="border:none;">
                        <i class="fa fa-shopping-cart icon-cart">
                                <span class="badge badge-danger">11</span>
                            </i><br>
                            AddToCart
                        </a>
                    </li>
               </ul>
            <form class="form-inline search-form">
             
						<input class="form-control search-input rounded-0 border-dark border-right-0" type="search" placeholder="Search for products, brands and more" aria-label="Search">
                  <button class="btn btn-light search-btn border-left-0 border-dark rounded-0" type="submit">
							<i class="fa fa-search text-secondary "></i>
						</button>
					</form>
         </div>
         <!-- /.nav-collapse -->
      </nav>